import { useState, useEffect, useRef } from "react";
import {
  ChevronDown, ChevronUp, ChevronRight, X, Check, AlertTriangle,
  Sparkles, Type, Image, MousePointerClick, Hash, Eye,
  TrendingUp, RefreshCw, Lightbulb, Shield, Palette, FileText,
  ArrowRight, Star, Zap, Target, MessageSquare, PenTool
} from "lucide-react";

/* ───────── design tokens (matched to Birdeye / Figma) ───────── */
const T = {
  blue:       "#2D68FE",
  blueLt:     "#EBF0FF",
  blueMd:     "#D6E2FF",
  green:      "#22C55E",
  greenLt:    "#ECFDF5",
  greenBg:    "#F0FDF4",
  yellow:     "#F59E0B",
  yellowLt:   "#FFFBEB",
  yellowBg:   "#FEF9C3",
  red:        "#EF4444",
  redLt:      "#FEF2F2",
  orange:     "#F97316",
  orangeLt:   "#FFF7ED",
  gray50:     "#F9FAFB",
  gray100:    "#F3F4F6",
  gray200:    "#E5E7EB",
  gray300:    "#D1D5DB",
  gray400:    "#9CA3AF",
  gray500:    "#6B7280",
  gray600:    "#4B5563",
  gray700:    "#374151",
  gray800:    "#1F2937",
  gray900:    "#111827",
  white:      "#FFFFFF",
  radius:     "8px",
  radiusSm:   "6px",
  radiusLg:   "12px",
  shadow:     "0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)",
  shadowLg:   "0 4px 12px rgba(0,0,0,0.1), 0 2px 4px rgba(0,0,0,0.06)",
  font:       '-apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, sans-serif',
};

/* ───────── mock brand identities ───────── */
const brandIdentities = [
  { id: 1, name: "Lushgreen Atlanta", logo: "🏡", domain: "lushgreenatlanta.com",
    voice: { personality: "Professional, Trustworthy", tone: "Warm & Approachable", style: "Educational, Clear" },
    kit: { colors: ["#2D5A27", "#F5A623", "#1A1A1A"], fonts: ["Montserrat", "Open Sans"] }
  },
  { id: 2, name: "Burger Barn", logo: "🍔", domain: "burgerbarn.com",
    voice: { personality: "Fun, Bold", tone: "Casual & Energetic", style: "Short, Punchy" },
    kit: { colors: ["#D32F2F", "#FF8F00", "#1B1B1B"], fonts: ["Poppins", "Roboto"] }
  },
  { id: 3, name: "Lumen Healthcare", logo: "🏥", domain: "lumenhealthcare.com",
    voice: { personality: "Caring, Expert", tone: "Empathetic & Reassuring", style: "Informative, Accessible" },
    kit: { colors: ["#1565C0", "#4CAF50", "#212121"], fonts: ["Inter", "Source Sans Pro"] }
  },
];

/* ───────── score data for demo ───────── */
const generateScoreData = (brand) => ({
  overall: 72,
  dimensions: [
    {
      key: "voice",
      label: "Brand Voice",
      icon: <MessageSquare size={16} />,
      score: 68,
      maxScore: 100,
      status: "warning",
      details: `Tone should be "${brand.voice.tone}"`,
      suggestions: [
        { id: "v1", text: `Adjust tone to be more ${brand.voice.tone.toLowerCase()} — current copy reads too formal`, type: "tone", priority: "high", impact: +8 },
        { id: "v2", text: `Add a personal touch that reflects "${brand.voice.personality}" personality`, type: "personality", priority: "medium", impact: +5 },
        { id: "v3", text: `Simplify language to match "${brand.voice.style}" writing style`, type: "style", priority: "low", impact: +3 },
      ]
    },
    {
      key: "visual",
      label: "Visual Identity",
      icon: <Palette size={16} />,
      score: 82,
      maxScore: 100,
      status: "good",
      details: "Media mostly aligns with brand guidelines",
      suggestions: [
        { id: "m1", text: "Image colors closely match brand palette — great job!", type: "positive", priority: "none", impact: 0 },
        { id: "m2", text: "Consider adding the brand logo as a watermark overlay", type: "logo", priority: "low", impact: +4 },
      ]
    },
    {
      key: "cta",
      label: "Call to Action",
      icon: <MousePointerClick size={16} />,
      score: 55,
      maxScore: 100,
      status: "poor",
      details: "CTA needs improvement for brand alignment",
      suggestions: [
        { id: "c1", text: 'CTA button text "Learn More" is generic — use brand-specific action language', type: "text", priority: "high", impact: +12 },
        { id: "c2", text: "CTA link should point to a branded landing page, not a generic URL", type: "link", priority: "high", impact: +8 },
      ]
    },
    {
      key: "hashtags",
      label: "Hashtags & Keywords",
      icon: <Hash size={16} />,
      score: 78,
      maxScore: 100,
      status: "good",
      details: "Good hashtag usage, minor improvements possible",
      suggestions: [
        { id: "h1", text: "Add branded hashtag #LushgreenHomes to increase brand recall", type: "add", priority: "medium", impact: +5 },
        { id: "h2", text: "Remove #StartYourJourney — too generic, dilutes brand voice", type: "remove", priority: "low", impact: +2 },
      ]
    },
  ]
});

/* ───────── circular score gauge ───────── */
function ScoreGauge({ score, size = 120, strokeWidth = 10, animate = true }) {
  const [displayScore, setDisplayScore] = useState(animate ? 0 : score);
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (displayScore / 100) * circumference;

  const getColor = (s) => s >= 80 ? T.green : s >= 60 ? T.yellow : T.red;
  const getLabel = (s) => s >= 80 ? "On Brand" : s >= 60 ? "Needs Work" : "Off Brand";

  useEffect(() => {
    if (!animate) return;
    let start = 0;
    const duration = 1200;
    const startTime = Date.now();
    const tick = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayScore(Math.round(eased * score));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [score, animate]);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "8px" }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
          <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={T.gray100} strokeWidth={strokeWidth} />
          <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={getColor(displayScore)} strokeWidth={strokeWidth}
            strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
            style={{ transition: animate ? "none" : "stroke-dashoffset 0.6s ease" }} />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontSize: "32px", fontWeight: 700, color: T.gray900, lineHeight: 1 }}>{displayScore}</span>
          <span style={{ fontSize: "12px", color: T.gray500, marginTop: "2px" }}>/100</span>
        </div>
      </div>
      <span style={{
        fontSize: "12px", fontWeight: 600, color: getColor(displayScore),
        background: score >= 80 ? T.greenLt : score >= 60 ? T.yellowLt : T.redLt,
        padding: "2px 10px", borderRadius: "20px",
      }}>
        {getLabel(displayScore)}
      </span>
    </div>
  );
}

/* ───────── mini bar for dimension scores ───────── */
function ScoreBar({ score, height = 6 }) {
  const color = score >= 80 ? T.green : score >= 60 ? T.yellow : score >= 40 ? T.orange : T.red;
  return (
    <div style={{ flex: 1, height, background: T.gray100, borderRadius: height/2, overflow: "hidden" }}>
      <div style={{ width: `${score}%`, height: "100%", background: color, borderRadius: height/2, transition: "width 0.8s ease" }} />
    </div>
  );
}

/* ───────── suggestion card ───────── */
function SuggestionCard({ suggestion, onApply, applied }) {
  const priorityStyles = {
    high: { bg: T.redLt, color: T.red, label: "High Impact" },
    medium: { bg: T.yellowLt, color: T.yellow, label: "Medium" },
    low: { bg: T.gray100, color: T.gray500, label: "Low" },
    none: { bg: T.greenLt, color: T.green, label: "" },
  };
  const ps = priorityStyles[suggestion.priority] || priorityStyles.low;
  const isPositive = suggestion.type === "positive";

  return (
    <div style={{
      display: "flex", gap: "10px", padding: "10px 12px", borderRadius: T.radiusSm,
      background: applied ? T.greenLt : isPositive ? T.greenLt : T.white,
      border: `1px solid ${applied ? T.green : isPositive ? "#BBF7D0" : T.gray200}`,
      transition: "all 0.2s ease", opacity: applied ? 0.7 : 1,
    }}>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: "13px", color: T.gray700, lineHeight: "18px", margin: 0 }}>
          {isPositive && <Check size={13} color={T.green} style={{ marginRight: 4, verticalAlign: "middle" }} />}
          {suggestion.text}
        </p>
        <div style={{ display: "flex", gap: "8px", marginTop: "6px", alignItems: "center" }}>
          {suggestion.priority !== "none" && (
            <span style={{ fontSize: "11px", fontWeight: 500, color: ps.color, background: ps.bg, padding: "1px 6px", borderRadius: "4px" }}>
              {ps.label}
            </span>
          )}
          {suggestion.impact > 0 && (
            <span style={{ fontSize: "11px", color: T.green, fontWeight: 500 }}>
              +{suggestion.impact} pts
            </span>
          )}
        </div>
      </div>
      {!isPositive && !applied && (
        <button onClick={() => onApply(suggestion.id)} style={{
          background: "none", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
          padding: "4px 10px", fontSize: "12px", color: T.blue, cursor: "pointer",
          fontWeight: 500, whiteSpace: "nowrap", alignSelf: "center",
          transition: "all 0.15s ease",
        }}
          onMouseOver={e => { e.currentTarget.style.background = T.blueLt; e.currentTarget.style.borderColor = T.blue; }}
          onMouseOut={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.borderColor = T.gray200; }}
        >
          Apply
        </button>
      )}
      {applied && (
        <div style={{ alignSelf: "center", display: "flex", alignItems: "center", gap: "4px", color: T.green, fontSize: "12px", fontWeight: 500 }}>
          <Check size={14} /> Applied
        </div>
      )}
    </div>
  );
}

/* ───────── dimension accordion ───────── */
function DimensionSection({ dimension, appliedSuggestions, onApply }) {
  const [expanded, setExpanded] = useState(false);
  const color = dimension.score >= 80 ? T.green : dimension.score >= 60 ? T.yellow : dimension.score >= 40 ? T.orange : T.red;

  return (
    <div style={{ borderRadius: T.radiusSm, border: `1px solid ${T.gray200}`, overflow: "hidden", background: T.white }}>
      <button onClick={() => setExpanded(!expanded)} style={{
        width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "12px 14px",
        background: "none", border: "none", cursor: "pointer", textAlign: "left",
      }}>
        <div style={{ color: color, display: "flex", alignItems: "center" }}>{dimension.icon}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "4px" }}>
            <span style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{dimension.label}</span>
            <span style={{ fontSize: "13px", fontWeight: 700, color }}>{dimension.score}</span>
          </div>
          <ScoreBar score={dimension.score} />
        </div>
        <div style={{ color: T.gray400, transition: "transform 0.2s", transform: expanded ? "rotate(180deg)" : "rotate(0)" }}>
          <ChevronDown size={16} />
        </div>
      </button>
      {expanded && (
        <div style={{ padding: "0 14px 14px", display: "flex", flexDirection: "column", gap: "8px", borderTop: `1px solid ${T.gray100}` }}>
          <p style={{ fontSize: "12px", color: T.gray500, margin: "10px 0 4px", lineHeight: "16px" }}>{dimension.details}</p>
          {dimension.suggestions.map(s => (
            <SuggestionCard key={s.id} suggestion={s} applied={appliedSuggestions.has(s.id)} onApply={onApply} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ───────── brand identity dropdown ───────── */
function BrandSelector({ brands, selected, onSelect, open, setOpen }) {
  return (
    <div style={{ position: "relative" }}>
      <button onClick={() => setOpen(!open)} style={{
        width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "8px 12px",
        background: T.white, border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
        cursor: "pointer", transition: "border-color 0.15s",
      }}
        onMouseOver={e => e.currentTarget.style.borderColor = T.blue}
        onMouseOut={e => { if(!open) e.currentTarget.style.borderColor = T.gray200; }}
      >
        <span style={{ fontSize: "20px" }}>{selected.logo}</span>
        <div style={{ flex: 1, textAlign: "left" }}>
          <div style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{selected.name}</div>
          <div style={{ fontSize: "11px", color: T.gray500 }}>{selected.domain}</div>
        </div>
        <ChevronDown size={16} color={T.gray400} style={{ transition: "transform 0.2s", transform: open ? "rotate(180deg)" : "rotate(0)" }} />
      </button>
      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 10,
          background: T.white, border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
          boxShadow: T.shadowLg, overflow: "hidden",
        }}>
          {brands.map(b => (
            <button key={b.id} onClick={() => { onSelect(b); setOpen(false); }} style={{
              width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "10px 12px",
              background: b.id === selected.id ? T.blueLt : "none", border: "none", cursor: "pointer",
              borderBottom: `1px solid ${T.gray100}`, textAlign: "left",
            }}
              onMouseOver={e => { if(b.id !== selected.id) e.currentTarget.style.background = T.gray50; }}
              onMouseOut={e => { if(b.id !== selected.id) e.currentTarget.style.background = "none"; }}
            >
              <span style={{ fontSize: "18px" }}>{b.logo}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "13px", fontWeight: 500, color: T.gray800 }}>{b.name}</div>
                <div style={{ fontSize: "11px", color: T.gray500 }}>{b.domain}</div>
              </div>
              {b.id === selected.id && <Check size={16} color={T.blue} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ───────── voice & kit summary pills ───────── */
function BrandSummary({ brand }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px", padding: "12px", background: T.gray50, borderRadius: T.radiusSm }}>
      <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "2px" }}>
        <Shield size={13} color={T.blue} />
        <span style={{ fontSize: "12px", fontWeight: 600, color: T.gray700 }}>Brand Guidelines</span>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "4px" }}>
        {["Personality", "Tone", "Style"].map((key, i) => {
          const val = [brand.voice.personality, brand.voice.tone, brand.voice.style][i];
          return (
            <span key={key} style={{ fontSize: "11px", padding: "2px 8px", borderRadius: "12px", background: T.blueLt, color: T.blue, fontWeight: 500 }}>
              {key}: {val}
            </span>
          );
        })}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px" }}>
        <Palette size={12} color={T.gray500} />
        <div style={{ display: "flex", gap: "4px" }}>
          {brand.kit.colors.map((c, i) => (
            <div key={i} style={{ width: 16, height: 16, borderRadius: "4px", background: c, border: `1px solid ${T.gray200}` }} />
          ))}
        </div>
        <span style={{ fontSize: "11px", color: T.gray500, marginLeft: "4px" }}>{brand.kit.fonts.join(", ")}</span>
      </div>
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════
   MAIN COMPONENT — full Create Post page with Brand Score panel
   ═══════════════════════════════════════════════════════════════ */
export default function BrandScorePanel() {
  const [panelOpen, setPanelOpen] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState(brandIdentities[0]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scoreData, setScoreData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [appliedSuggestions, setAppliedSuggestions] = useState(new Set());
  const [activeTab, setActiveTab] = useState("score"); // score | suggestions

  const runScoring = () => {
    setLoading(true);
    setAppliedSuggestions(new Set());
    setTimeout(() => {
      setScoreData(generateScoreData(selectedBrand));
      setLoading(false);
    }, 1800);
  };

  const handleApply = (id) => {
    setAppliedSuggestions(prev => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const openPanel = () => {
    setPanelOpen(true);
    if (!scoreData) runScoring();
  };

  const totalSuggestions = scoreData ? scoreData.dimensions.reduce((a, d) => a + d.suggestions.filter(s => s.type !== "positive").length, 0) : 0;
  const appliedCount = appliedSuggestions.size;

  /* ───────── page layout ───────── */
  return (
    <div style={{ fontFamily: T.font, background: "#F5F7FA", minHeight: "100vh", display: "flex", flexDirection: "column" }}>

      {/* ── top nav ── */}
      <div style={{ height: "48px", background: T.white, borderBottom: `1px solid ${T.gray200}`, display: "flex", alignItems: "center", padding: "0 16px", zIndex: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div style={{ width: 24, height: 24, borderRadius: "6px", background: T.blue, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: T.white, fontSize: "14px", fontWeight: 700 }}>B</span>
          </div>
          <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray800 }}>Social AI</span>
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", gap: "16px", alignItems: "center" }}>
          {["help", "settings", "user"].map((_, i) => (
            <div key={i} style={{ width: 28, height: 28, borderRadius: "50%", background: T.gray100, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ width: 14, height: 14, borderRadius: "50%", background: T.gray300 }} />
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flex: 1 }}>
        {/* ── left rail nav ── */}
        <div style={{ width: "48px", background: T.white, borderRight: `1px solid ${T.gray200}`, display: "flex", flexDirection: "column", alignItems: "center", paddingTop: "12px", gap: "8px" }}>
          {Array.from({length: 8}).map((_, i) => (
            <div key={i} style={{
              width: 32, height: 32, borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center",
              background: i === 6 ? T.blueLt : "transparent",
            }}>
              <div style={{ width: 16, height: 16, borderRadius: "4px", background: i === 6 ? T.blue : T.gray300 }} />
            </div>
          ))}
        </div>

        {/* ── main content area ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {/* ── header bar ── */}
          <div style={{
            height: "56px", background: T.white, borderBottom: `1px solid ${T.gray200}`,
            display: "flex", alignItems: "center", padding: "0 24px", gap: "12px",
          }}>
            <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", color: T.gray600 }}>
              <ChevronDown size={18} style={{ transform: "rotate(90deg)" }} />
            </button>
            <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray900 }}>Create post</span>
            <div style={{ flex: 1 }} />

            {/* ── BRAND SCORE TRIGGER BUTTON ── */}
            <button onClick={openPanel} style={{
              display: "flex", alignItems: "center", gap: "6px", padding: "7px 14px",
              background: panelOpen ? T.blueLt : T.white,
              border: `1px solid ${panelOpen ? T.blue : T.gray200}`,
              borderRadius: T.radiusSm, cursor: "pointer", transition: "all 0.2s",
              position: "relative",
            }}
              onMouseOver={e => { if(!panelOpen) { e.currentTarget.style.borderColor = T.blue; e.currentTarget.style.background = T.blueLt; }}}
              onMouseOut={e => { if(!panelOpen) { e.currentTarget.style.borderColor = T.gray200; e.currentTarget.style.background = T.white; }}}
            >
              <Shield size={15} color={T.blue} />
              <span style={{ fontSize: "13px", fontWeight: 500, color: panelOpen ? T.blue : T.gray700 }}>Brand Score</span>
              {scoreData && !panelOpen && (
                <span style={{
                  fontSize: "11px", fontWeight: 700, color: T.white, minWidth: "22px", height: "18px",
                  borderRadius: "9px", display: "flex", alignItems: "center", justifyContent: "center", padding: "0 5px",
                  background: scoreData.overall >= 80 ? T.green : scoreData.overall >= 60 ? T.yellow : T.red,
                }}>
                  {scoreData.overall}
                </span>
              )}
            </button>

            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: T.gray600, cursor: "pointer" }}>
                <div style={{ width: 18, height: 18, borderRadius: "4px", background: T.blue, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Check size={12} color={T.white} />
                </div>
                Add to post library
              </label>
            </div>
            <button style={{
              padding: "8px 20px", background: T.blue, color: T.white, border: "none",
              borderRadius: T.radiusSm, fontSize: "13px", fontWeight: 600, cursor: "pointer",
              display: "flex", alignItems: "center", gap: "4px",
            }}>
              Schedule
              <ChevronDown size={14} />
            </button>
          </div>

          {/* ── body: composer + preview + brand panel ── */}
          <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

            {/* ── LEFT: post composer ── */}
            <div style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "20px 24px" }}>

              {/* channel pills */}
              <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "6px 10px", display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap", marginBottom: "16px" }}>
                {[
                  { name: "Facebook", color: "#1877F2" },
                  { name: "Instagram", color: "#E4405F" },
                  { name: "LinkedIn", color: "#0A66C2" },
                ].map(ch => (
                  <span key={ch.name} style={{
                    display: "flex", alignItems: "center", gap: "6px", padding: "4px 10px",
                    background: T.gray50, borderRadius: "16px", fontSize: "12px", color: T.gray700,
                  }}>
                    <div style={{ width: 14, height: 14, borderRadius: "50%", background: ch.color }} />
                    {ch.name}
                    <X size={12} color={T.gray400} style={{ cursor: "pointer" }} />
                  </span>
                ))}
                <span style={{ fontSize: "12px", color: T.blue, cursor: "pointer", fontWeight: 500 }}>3 more</span>
                <div style={{ flex: 1 }} />
                <ChevronUp size={16} color={T.gray400} />
              </div>

              {/* text editor area */}
              <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, marginBottom: "16px" }}>
                <div style={{ display: "flex", borderBottom: `1px solid ${T.gray200}` }}>
                  {["Default", "Facebook", "Instagram"].map((tab, i) => (
                    <button key={tab} style={{
                      padding: "10px 16px", fontSize: "13px", fontWeight: i === 0 ? 600 : 400,
                      color: i === 0 ? T.blue : T.gray500, background: "none", border: "none",
                      borderBottom: i === 0 ? `2px solid ${T.blue}` : "2px solid transparent",
                      cursor: "pointer",
                    }}>
                      {tab}
                    </button>
                  ))}
                </div>
                <div style={{ padding: "16px" }}>
                  <p style={{ fontSize: "14px", color: T.gray800, lineHeight: "22px", margin: 0 }}>
                    Nothing beats a freshly grilled burger stacked with juicy patties, soft buns, and bold flavors in every bite. At our shop, we keep it simple—real ingredients, perfect grills, and burgers made to satisfy serious cravings. From the first bite to the last crumb, it's comfort, indulgence, and happiness all wrapped in one burger. Come hungry, eat happy, and leave planning your next visit. 🍔🔥
                  </p>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "16px", borderTop: `1px solid ${T.gray100}`, paddingTop: "10px" }}>
                    <div style={{ display: "flex", gap: "12px" }}>
                      <div style={{ width: 20, height: 20, borderRadius: "4px", background: T.gray200 }} />
                      <div style={{ width: 20, height: 20, borderRadius: "4px", background: T.gray200 }} />
                      <div style={{ width: 20, height: 20, borderRadius: "4px", background: `linear-gradient(135deg, ${T.blue}, #8B5CF6)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Sparkles size={12} color={T.white} />
                      </div>
                    </div>
                    <span style={{ fontSize: "12px", color: T.blue, cursor: "pointer" }}>Add to post library</span>
                  </div>
                </div>
              </div>
              <span style={{ fontSize: "12px", color: T.gray500, display: "block", marginTop: "-10px", marginBottom: "16px" }}>144 characters left</span>

              {/* media preview */}
              <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px", marginBottom: "16px" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <Image size={16} color={T.gray600} />
                    <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>Call to action</span>
                  </div>
                  <ChevronUp size={16} color={T.gray400} />
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <div style={{ width: 88, height: 88, borderRadius: T.radiusSm, background: "linear-gradient(135deg, #3B82F6, #06B6D4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Image size={24} color="rgba(255,255,255,0.8)" />
                  </div>
                  <div style={{ width: 88, height: 88, borderRadius: T.radiusSm, border: `2px dashed ${T.gray300}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                    <span style={{ fontSize: "24px", color: T.gray400 }}>+</span>
                  </div>
                </div>
              </div>

              {/* CTA section */}
              <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px", marginBottom: "16px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                  <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>CTA</span>
                  <span style={{ fontSize: "14px" }}>ℹ️</span>
                  <span style={{ fontSize: "11px", fontWeight: 500, background: T.blueLt, color: T.blue, padding: "2px 8px", borderRadius: "4px" }}>New</span>
                  <div style={{ flex: 1 }} />
                  <span style={{ fontSize: "12px", color: T.blue, cursor: "pointer" }}>Learn more</span>
                </div>
                <div style={{
                  padding: "10px 14px", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
                  fontSize: "13px", color: T.gray500, display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <span>Select CTA type</span>
                  <ChevronDown size={16} color={T.gray400} />
                </div>
              </div>

              {/* Hashtags */}
              <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                  <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>Hashtags</span>
                  <span style={{ fontSize: "14px" }}>ℹ️</span>
                </div>
                <div style={{
                  padding: "10px 14px", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
                  fontSize: "13px", color: T.gray500, display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <span>AI generated hashtag group</span>
                  <ChevronDown size={16} color={T.gray400} />
                </div>
              </div>
            </div>

            {/* ── MIDDLE: preview pane ── */}
            <div style={{
              width: panelOpen ? "340px" : "420px",
              transition: "width 0.3s ease",
              borderLeft: `1px solid ${T.gray200}`, background: T.white, overflow: "auto", padding: "20px",
              flexShrink: 0,
            }}>
              <div style={{ marginBottom: "4px" }}>
                <span style={{ fontSize: "14px", fontWeight: 600, color: T.gray800 }}>Preview</span>
              </div>
              <p style={{ fontSize: "11px", color: T.gray500, margin: "0 0 16px", lineHeight: "16px" }}>
                Preview approximates how your content will display when published.
              </p>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "16px" }}>
                <div style={{ width: 16, height: 16, borderRadius: "50%", background: "#1877F2" }} />
                <span style={{ fontSize: "13px", fontWeight: 500, color: T.gray800 }}>Facebook</span>
                <span style={{ fontSize: "13px", color: T.blue }}>3 Pages</span>
                <div style={{ flex: 1 }} />
                <ChevronUp size={16} color={T.gray400} />
              </div>

              {/* mock facebook post preview */}
              <div style={{ border: `1px solid ${T.gray200}`, borderRadius: T.radius, overflow: "hidden" }}>
                <div style={{ padding: "14px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
                    <div style={{ width: 36, height: 36, borderRadius: "50%", background: T.green, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px" }}>🏡</div>
                    <span style={{ fontSize: "14px", fontWeight: 600, color: T.gray900 }}>Lushgreen Atlanta</span>
                  </div>
                  <p style={{ fontSize: "13px", color: T.gray700, lineHeight: "20px", margin: 0 }}>
                    Nothing beats a freshly grilled burger stacked with juicy patties, soft buns, and bold flavors...
                  </p>
                  <p style={{ fontSize: "12px", color: T.blue, margin: "8px 0 0", lineHeight: "18px" }}>
                    #EarnestMoney #SeriousBuyer #HomeBuyingTips
                  </p>
                </div>
                <div style={{ height: "140px", background: "linear-gradient(135deg, #1E88E5, #0D47A1)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ color: T.white, fontSize: "15px", fontWeight: 700, textAlign: "center", padding: "0 20px", lineHeight: "22px" }}>
                    Buyers pay sellers earnest money to show they are serious
                  </span>
                </div>
              </div>
            </div>

            {/* ── RIGHT: brand score panel (slide-in) ── */}
            <div style={{
              width: panelOpen ? "360px" : "0px",
              transition: "width 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              overflow: "hidden", borderLeft: panelOpen ? `1px solid ${T.gray200}` : "none",
              background: T.white, flexShrink: 0,
            }}>
              <div style={{ width: "360px", height: "100%", overflow: "auto", display: "flex", flexDirection: "column" }}>

                {/* panel header */}
                <div style={{
                  padding: "16px 20px", borderBottom: `1px solid ${T.gray200}`,
                  display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, background: T.white, zIndex: 5,
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <Shield size={18} color={T.blue} />
                    <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray900 }}>Brand Score</span>
                  </div>
                  <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                    <button onClick={runScoring} title="Re-analyze" style={{
                      background: "none", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm,
                      padding: "4px", cursor: "pointer", display: "flex", alignItems: "center",
                    }}
                      onMouseOver={e => e.currentTarget.style.background = T.gray50}
                      onMouseOut={e => e.currentTarget.style.background = "none"}
                    >
                      <RefreshCw size={14} color={T.gray500} />
                    </button>
                    <button onClick={() => setPanelOpen(false)} style={{
                      background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", padding: "4px",
                    }}>
                      <X size={18} color={T.gray500} />
                    </button>
                  </div>
                </div>

                {/* panel body */}
                <div style={{ padding: "20px", flex: 1, display: "flex", flexDirection: "column", gap: "16px" }}>

                  {/* brand selector */}
                  <div>
                    <label style={{ fontSize: "12px", fontWeight: 500, color: T.gray500, display: "block", marginBottom: "6px" }}>Brand Identity</label>
                    <BrandSelector brands={brandIdentities} selected={selectedBrand} onSelect={(b) => { setSelectedBrand(b); setScoreData(null); setTimeout(runScoring, 100); }} open={dropdownOpen} setOpen={setDropdownOpen} />
                  </div>

                  {/* brand summary */}
                  <BrandSummary brand={selectedBrand} />

                  {/* loading state */}
                  {loading && (
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "40px 20px", gap: "16px" }}>
                      <div style={{
                        width: 48, height: 48, borderRadius: "50%",
                        border: `3px solid ${T.gray200}`, borderTopColor: T.blue,
                        animation: "spin 1s linear infinite",
                      }} />
                      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
                      <div style={{ textAlign: "center" }}>
                        <p style={{ fontSize: "14px", fontWeight: 500, color: T.gray800, margin: "0 0 4px" }}>Analyzing your post...</p>
                        <p style={{ fontSize: "12px", color: T.gray500, margin: 0 }}>Checking content, media, CTAs & hashtags against brand guidelines</p>
                      </div>
                    </div>
                  )}

                  {/* score results */}
                  {!loading && scoreData && (
                    <>
                      {/* overall gauge */}
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 0" }}>
                        <ScoreGauge score={scoreData.overall} />
                        <p style={{ fontSize: "12px", color: T.gray500, marginTop: "8px", textAlign: "center" }}>
                          Your post is <strong style={{ color: T.gray700 }}>{scoreData.overall >= 80 ? "well aligned" : scoreData.overall >= 60 ? "partially aligned" : "not aligned"}</strong> with {selectedBrand.name}'s brand identity
                        </p>
                      </div>

                      {/* tab switcher */}
                      <div style={{ display: "flex", background: T.gray100, borderRadius: T.radiusSm, padding: "3px" }}>
                        {[
                          { key: "score", label: "Score Breakdown" },
                          { key: "suggestions", label: `Suggestions (${totalSuggestions})` },
                        ].map(tab => (
                          <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
                            flex: 1, padding: "7px 12px", fontSize: "12px", fontWeight: 500,
                            background: activeTab === tab.key ? T.white : "transparent",
                            color: activeTab === tab.key ? T.gray800 : T.gray500,
                            border: "none", borderRadius: "4px", cursor: "pointer",
                            boxShadow: activeTab === tab.key ? "0 1px 2px rgba(0,0,0,0.06)" : "none",
                            transition: "all 0.15s ease",
                          }}>
                            {tab.label}
                          </button>
                        ))}
                      </div>

                      {/* score breakdown tab */}
                      {activeTab === "score" && (
                        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                          {scoreData.dimensions.map(dim => (
                            <DimensionSection key={dim.key} dimension={dim} appliedSuggestions={appliedSuggestions} onApply={handleApply} />
                          ))}
                        </div>
                      )}

                      {/* suggestions tab — flat list */}
                      {activeTab === "suggestions" && (
                        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                          {appliedCount > 0 && (
                            <div style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 12px", background: T.greenLt, borderRadius: T.radiusSm }}>
                              <TrendingUp size={14} color={T.green} />
                              <span style={{ fontSize: "12px", color: T.green, fontWeight: 500 }}>
                                {appliedCount} of {totalSuggestions} suggestions applied — estimated score improvement: +{scoreData.dimensions.reduce((a, d) => a + d.suggestions.filter(s => appliedSuggestions.has(s.id)).reduce((b, s) => b + s.impact, 0), 0)} pts
                              </span>
                            </div>
                          )}
                          {scoreData.dimensions.map(dim => (
                            dim.suggestions.filter(s => s.type !== "positive").map(s => (
                              <div key={s.id}>
                                <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                                  <span style={{ color: dim.score >= 80 ? T.green : dim.score >= 60 ? T.yellow : T.red }}>{dim.icon}</span>
                                  <span style={{ fontSize: "11px", fontWeight: 600, color: T.gray500, textTransform: "uppercase", letterSpacing: "0.5px" }}>{dim.label}</span>
                                </div>
                                <SuggestionCard suggestion={s} applied={appliedSuggestions.has(s.id)} onApply={handleApply} />
                              </div>
                            ))
                          ))}
                        </div>
                      )}

                      {/* apply all CTA */}
                      {appliedCount < totalSuggestions && (
                        <button onClick={() => {
                          scoreData.dimensions.forEach(d => d.suggestions.forEach(s => { if(s.type !== "positive") handleApply(s.id); }));
                        }} style={{
                          width: "100%", padding: "10px", background: T.blue, color: T.white,
                          border: "none", borderRadius: T.radiusSm, fontSize: "13px", fontWeight: 600,
                          cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
                          transition: "background 0.15s",
                        }}
                          onMouseOver={e => e.currentTarget.style.background = "#1D4FE0"}
                          onMouseOut={e => e.currentTarget.style.background = T.blue}
                        >
                          <Zap size={14} />
                          Apply All Suggestions
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

import React from 'react'
import ReactDOM from 'react-dom/client'
import BrandScoreApp from './BrandScoreApp'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrandScoreApp />
  </React.StrictMode>,
)

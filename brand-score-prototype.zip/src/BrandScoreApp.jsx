import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  ChevronDown, ChevronUp, ChevronRight, ChevronLeft, X, Check, AlertTriangle,
  Sparkles, Type, Image, MousePointerClick, Hash, Eye, Globe, Link2,
  TrendingUp, RefreshCw, Lightbulb, Shield, Palette, FileText, Search,
  ArrowRight, ArrowLeft, Star, Zap, Target, MessageSquare, PenTool,
  Settings, Home, Users, BarChart3, Calendar, Mail, Bell, HelpCircle,
  Plus, Edit3, Trash2, ExternalLink, Upload, CheckCircle2, XCircle,
  Smile, Camera, Copy, BookOpen, Megaphone, Layout, Monitor
} from "lucide-react";

/* ════════════════════════════════════════════════════════════════
   DESIGN TOKENS — matched to Birdeye live app
   ════════════════════════════════════════════════════════════════ */
const T = {
  blue: "#2D68FE", blueHover: "#1D4FE0", blueLt: "#EBF0FF", blueMd: "#D6E2FF",
  green: "#22C55E", greenLt: "#ECFDF5", greenDk: "#16A34A",
  yellow: "#F59E0B", yellowLt: "#FFFBEB",
  red: "#EF4444", redLt: "#FEF2F2",
  orange: "#F97316", orangeLt: "#FFF7ED",
  purple: "#8B5CF6", purpleLt: "#F5F3FF",
  gray50: "#F9FAFB", gray100: "#F3F4F6", gray200: "#E5E7EB", gray300: "#D1D5DB",
  gray400: "#9CA3AF", gray500: "#6B7280", gray600: "#4B5563", gray700: "#374151",
  gray800: "#1F2937", gray900: "#111827",
  white: "#FFFFFF",
  radius: "8px", radiusSm: "6px", radiusLg: "12px", radiusXl: "16px",
  shadow: "0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)",
  shadowMd: "0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1)",
  shadowLg: "0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1)",
  font: '-apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, sans-serif',
};

/* ════════════════════════════════════════════════════════════════
   MOCK DATA — Brand Identities
   ════════════════════════════════════════════════════════════════ */
const DEFAULT_BRANDS = [
  {
    id: 1, name: "Lush Landscaping", isDefault: true, locations: "All locations",
    domain: "lushlandscaping.com", logo: "🌿", logoColor: "#2D5A27",
    voice: {
      personality: ["Friendly", "Professional", "Authentic"],
      tone: ["Persuasive", "Casual", "Simple"],
    },
    kit: {
      colors: { primary: "#4CAF50", secondary: "#E8F5E9", dark: "#2E7D32", headerFont: "#FFFFFF", bodyFont: "#1B5E20", ctaFont: "#FFFFFF" },
      fonts: { header: "Roboto", headerWeight: "Bold", body: "Roboto", bodyWeight: "Regular" },
      logos: ["lush-logo.png"],
    },
    createdBy: "Katie Sanders", createdOn: "Feb 06, 2026",
  },
  {
    id: 2, name: "Victoria's Secret Chicago", locations: "Mag Mile",
    domain: "victoriassecret.com", logo: "💗", logoColor: "#E91E63",
    voice: {
      personality: ["Elegant", "Bold", "Confident"],
      tone: ["Aspirational", "Empowering", "Luxurious"],
    },
    kit: {
      colors: { primary: "#E91E63", secondary: "#FCE4EC", dark: "#1A1A1A", headerFont: "#FFFFFF", bodyFont: "#212121", ctaFont: "#FFFFFF" },
      fonts: { header: "Playfair Display", headerWeight: "Bold", body: "Lato", bodyWeight: "Regular" },
      logos: ["vs-logo.png"],
    },
    createdBy: "Andy Carpenter", createdOn: "Feb 19, 2026",
  },
  {
    id: 3, name: "DR Horton", locations: "Hillsdale",
    domain: "drhorton.com", logo: "🏠", logoColor: "#1565C0",
    voice: {
      personality: ["Trustworthy", "Expert", "Welcoming"],
      tone: ["Informative", "Warm", "Clear"],
    },
    kit: {
      colors: { primary: "#1565C0", secondary: "#BBDEFB", dark: "#0D47A1", headerFont: "#FFFFFF", bodyFont: "#1A237E", ctaFont: "#FFFFFF" },
      fonts: { header: "Montserrat", headerWeight: "Bold", body: "Source Sans Pro", bodyWeight: "Regular" },
      logos: ["drh-logo.png"],
    },
    createdBy: "Andy Carpenter", createdOn: "Feb 26, 2026",
  },
];

const PERSONALITY_OPTIONS = ["Friendly", "Professional", "Authentic", "Bold", "Playful", "Elegant", "Caring", "Innovative", "Trustworthy", "Expert", "Welcoming", "Confident"];
const TONE_OPTIONS = ["Persuasive", "Casual", "Simple", "Formal", "Empowering", "Luxurious", "Aspirational", "Informative", "Warm", "Clear", "Energetic", "Empathetic"];
const FONT_OPTIONS = ["Roboto", "Inter", "Montserrat", "Open Sans", "Lato", "Poppins", "Playfair Display", "Source Sans Pro", "Raleway", "Merriweather"];

/* ════════════════════════════════════════════════════════════════
   DEFAULT SCORING CRITERIA
   ════════════════════════════════════════════════════════════════ */
const DEFAULT_CRITERIA = [
  { id: "voice", label: "Brand Voice", weight: 30, enabled: true, description: "Personality, tone & writing style alignment" },
  { id: "visual", label: "Visual Identity", weight: 25, enabled: true, description: "Logo usage, brand colors, image style" },
  { id: "cta", label: "Call to Action", weight: 20, enabled: true, description: "CTA text, link, and button alignment" },
  { id: "hashtags", label: "Hashtags & Keywords", weight: 15, enabled: true, description: "Branded hashtags and keyword relevance" },
  { id: "formatting", label: "Content Formatting", weight: 10, enabled: true, description: "Post length, emoji usage, readability" },
];

/* channel icons as colored divs */
const ChannelIcon = ({ type, size = 16 }) => {
  const colors = { facebook: "#1877F2", instagram: "#E4405F", linkedin: "#0A66C2", twitter: "#1DA1F2", google: "#4285F4", tiktok: "#010101" };
  const labels = { facebook: "f", instagram: "📷", linkedin: "in", twitter: "𝕏", google: "G", tiktok: "♪" };
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: colors[type] || T.gray400, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <span style={{ color: T.white, fontSize: size * 0.55, fontWeight: 700, lineHeight: 1 }}>{labels[type] || "?"}</span>
    </div>
  );
};

/* ════════════════════════════════════════════════════════════════
   SCORING ENGINE — generates detailed, content-aware scores
   ════════════════════════════════════════════════════════════════ */
function generateScores(brand, postContent, channels, criteria) {
  const content = postContent || "";
  const words = content.split(/\s+/).filter(Boolean);
  const hasEmoji = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u.test(content);
  const hasHashtags = /#\w+/.test(content);
  const hashtagList = content.match(/#\w+/g) || [];
  const sentenceCount = content.split(/[.!?]+/).filter(s => s.trim()).length;
  const avgWordLen = words.length ? words.reduce((a, w) => a + w.length, 0) / words.length : 0;
  const brandName = brand.name.toLowerCase();

  // Voice scoring
  const voiceScore = Math.min(95, 55 + (content.length > 50 ? 10 : 0) + (sentenceCount > 2 ? 8 : 0) + (avgWordLen < 7 ? 5 : 0) + (hasEmoji ? 4 : -2) + Math.floor(Math.random() * 8));
  // Visual scoring
  const visualScore = Math.min(90, 60 + Math.floor(Math.random() * 20) + (content.length > 100 ? 5 : 0));
  // CTA scoring
  const ctaScore = Math.min(88, 40 + (content.toLowerCase().includes("visit") || content.toLowerCase().includes("shop") || content.toLowerCase().includes("call") || content.toLowerCase().includes("learn") ? 20 : 0) + (content.includes("http") || content.includes("www") ? 10 : 0) + Math.floor(Math.random() * 15));
  // Hashtag scoring
  const hashScore = Math.min(92, 45 + (hashtagList.length > 0 ? 15 : 0) + (hashtagList.length > 3 ? 10 : 0) + (hashtagList.some(h => h.toLowerCase().includes(brandName.split(" ")[0]?.toLowerCase())) ? 15 : 0) + Math.floor(Math.random() * 10));
  // Formatting scoring
  const formatScore = Math.min(95, 50 + (words.length > 20 && words.length < 200 ? 15 : 0) + (sentenceCount > 1 && sentenceCount < 8 ? 10 : 0) + (hasEmoji ? 5 : 0) + Math.floor(Math.random() * 12));

  const scores = { voice: voiceScore, visual: visualScore, cta: ctaScore, hashtags: hashScore, formatting: formatScore };
  const enabledCriteria = criteria.filter(c => c.enabled);
  const totalWeight = enabledCriteria.reduce((a, c) => a + c.weight, 0);
  const overall = Math.round(enabledCriteria.reduce((a, c) => a + (scores[c.id] || 70) * (c.weight / totalWeight), 0));

  // Content-aware snippet extraction
  const firstSentence = content.split(/[.!?]/)[0]?.trim().substring(0, 60) || "your opening line";
  const lastSentence = content.split(/[.!?]/).filter(s => s.trim()).pop()?.trim().substring(0, 60) || "your closing line";

  // Build per-channel suggestions
  const channelSuggestions = {};
  const activeChannels = channels.length > 0 ? channels : ["facebook"];

  activeChannels.forEach(ch => {
    channelSuggestions[ch] = [];

    // Voice suggestions per channel
    if (scores.voice < 85) {
      if (ch === "facebook") {
        channelSuggestions[ch].push({
          id: `${ch}-v1`, dimension: "voice", priority: "high", impact: 8,
          text: `Facebook audiences respond best to conversational, story-driven posts. "${firstSentence}..." reads a bit formal.`,
          reasoning: `Your brand personality is "${brand.voice.personality.join(", ")}" but the opening feels corporate. Facebook's algorithm also favors posts that generate comments — questions and personal anecdotes drive 2-3x more engagement.`,
          action: "Rewrite the opening as a question or personal story hook",
          example: `Instead of "${firstSentence}...", try: "Ever wondered what makes the perfect [topic]? Here's what we've learned..."`,
        });
      }
      if (ch === "instagram") {
        channelSuggestions[ch].push({
          id: `${ch}-v1`, dimension: "voice", priority: "high", impact: 9,
          text: `Instagram captions should lead with a hook in the first line (before "...more"). "${firstSentence}..." may get cut off.`,
          reasoning: `Instagram truncates captions after ~125 characters. Your brand tone is "${brand.voice.tone.join(", ")}" — lead with the most compelling statement to stop the scroll.`,
          action: "Front-load the caption with an attention-grabbing first line",
          example: `Lead with something punchy like: "This changes everything 👇" or a bold brand statement.`,
        });
      }
      if (ch === "linkedin") {
        channelSuggestions[ch].push({
          id: `${ch}-v1`, dimension: "voice", priority: "medium", impact: 6,
          text: `LinkedIn favors thought leadership and value-driven content. The tone could be more authoritative.`,
          reasoning: `Your brand personality includes "${brand.voice.personality[0]}" — on LinkedIn, framing insights as expertise drives higher engagement. Posts with data or specific takeaways get 3x more shares.`,
          action: "Add a specific insight, statistic, or professional takeaway",
          example: `Add a line like: "Here's what 10 years in [industry] taught us about [topic]..."`,
        });
      }
    }

    // Visual suggestions per channel
    if (scores.visual < 85) {
      if (ch === "facebook") {
        channelSuggestions[ch].push({
          id: `${ch}-m1`, dimension: "visual", priority: "medium", impact: 6,
          text: "Post image doesn't include your brand logo — Facebook posts with branded visuals get 23% more recognition.",
          reasoning: `Your brand kit specifies "${brand.kit.fonts.header}" font and primary color ${brand.kit.colors.primary}. Adding a subtle logo watermark or brand-colored border reinforces identity in the feed.`,
          action: "Add brand logo overlay or brand-colored frame to the image",
        });
      }
      if (ch === "instagram") {
        channelSuggestions[ch].push({
          id: `${ch}-m1`, dimension: "visual", priority: "high", impact: 10,
          text: "Image colors don't closely match your brand palette — Instagram's visual-first feed makes color consistency critical.",
          reasoning: `Your brand colors are ${brand.kit.colors.primary} (primary) and ${brand.kit.colors.secondary} (secondary). Consistent color use across posts builds a recognizable grid aesthetic, which increases profile visits by up to 40%.`,
          action: "Apply a brand-colored filter or overlay to align with your palette",
        });
        channelSuggestions[ch].push({
          id: `${ch}-m2`, dimension: "visual", priority: "medium", impact: 5,
          text: "Consider localizing this image for your specific market — geo-relevant visuals perform 35% better.",
          reasoning: `Your brand targets "${brand.locations}" locations. Using locally recognizable landmarks, people, or settings creates stronger emotional connection with your local audience.`,
          action: "Use location-specific imagery that your local audience will recognize",
        });
      }
      if (ch === "linkedin") {
        channelSuggestions[ch].push({
          id: `${ch}-m1`, dimension: "visual", priority: "low", impact: 4,
          text: "LinkedIn images perform best at 1200x627px with clean, professional styling.",
          reasoning: `Your brand font "${brand.kit.fonts.header}" and dark color ${brand.kit.colors.dark} project professionalism. Ensure any text overlays use these brand elements for consistency.`,
          action: "Verify image dimensions and add brand-styled text overlay if applicable",
        });
      }
    }

    // CTA suggestions per channel
    if (scores.cta < 75) {
      const ctaWords = ["visit", "shop", "learn", "call", "book", "get", "try", "discover"];
      const hasCTA = ctaWords.some(w => content.toLowerCase().includes(w));
      channelSuggestions[ch].push({
        id: `${ch}-c1`, dimension: "cta", priority: "high", impact: hasCTA ? 5 : 12,
        text: hasCTA
          ? `Your CTA "${ctaWords.find(w => content.toLowerCase().includes(w))}" is generic — brand-aligned CTAs convert 2x better.`
          : `No clear call-to-action detected. "${lastSentence}..." ends without directing the reader.`,
        reasoning: hasCTA
          ? `Brand voice is "${brand.voice.tone[0]}" — your CTA should match this energy. Generic CTAs like "Learn more" underperform compared to brand-specific language.`
          : `Every post should guide the reader to a next step. For "${brand.voice.personality[0]}" brands, the CTA should feel like a natural invitation, not a hard sell.`,
        action: hasCTA ? "Replace with a brand-voice-aligned CTA" : "Add a clear, on-brand call-to-action",
        example: ch === "instagram"
          ? "Instagram CTAs work best in bio link references: 'Link in bio for more 👆'"
          : ch === "facebook"
            ? `Try: "Ready to experience ${brand.name}? [Link] 🔗" or use the CTA button feature`
            : `Try: "Want to learn how? Read our latest insights → [Link]"`,
      });
    }

    // Hashtag suggestions per channel
    if (scores.hashtags < 85) {
      const brandHashtag = `#${brand.name.replace(/\s+/g, "")}`;
      const hasBrandTag = hashtagList.some(h => h.toLowerCase().includes(brand.name.split(" ")[0].toLowerCase()));
      if (!hasBrandTag) {
        channelSuggestions[ch].push({
          id: `${ch}-h1`, dimension: "hashtags", priority: "medium", impact: 6,
          text: `Missing branded hashtag — add "${brandHashtag}" for brand recall and tracking.`,
          reasoning: `Branded hashtags create a searchable content library. Users who follow or search "${brandHashtag}" see all your posts in one place, building brand awareness over time.`,
          action: `Add ${brandHashtag} to your hashtag set`,
        });
      }
      if (ch === "instagram" && hashtagList.length < 5) {
        channelSuggestions[ch].push({
          id: `${ch}-h2`, dimension: "hashtags", priority: "medium", impact: 7,
          text: `Only ${hashtagList.length} hashtags — Instagram posts perform best with 8-15 relevant hashtags.`,
          reasoning: `Instagram's algorithm uses hashtags for discovery. Mix branded tags, industry tags, and niche community tags for maximum reach. Posts with 11+ hashtags get 79% more engagement.`,
          action: "Add a mix of branded, industry, and niche hashtags (aim for 8-15 total)",
        });
      }
      if (ch === "linkedin" && hashtagList.length > 5) {
        channelSuggestions[ch].push({
          id: `${ch}-h2`, dimension: "hashtags", priority: "low", impact: 3,
          text: `${hashtagList.length} hashtags is too many for LinkedIn — stick to 3-5 highly relevant ones.`,
          reasoning: `LinkedIn's algorithm penalizes posts with too many hashtags as spammy. Focus on industry-specific tags that your target audience follows.`,
          action: "Reduce to 3-5 targeted hashtags",
        });
      }
    }

    // Formatting suggestions
    if (scores.formatting < 85) {
      if (ch === "facebook" && words.length > 150) {
        channelSuggestions[ch].push({
          id: `${ch}-f1`, dimension: "formatting", priority: "low", impact: 3,
          text: `At ${words.length} words, this post is long for Facebook. Optimal length is 40-80 words.`,
          reasoning: `Facebook's "See more" truncation kicks in around 480 characters. Shorter, punchier posts aligned with your "${brand.voice.tone[0]}" tone drive higher engagement.`,
          action: "Trim to the most impactful 40-80 words",
        });
      }
      if (ch === "twitter" && words.length > 45) {
        channelSuggestions[ch].push({
          id: `${ch}-f1`, dimension: "formatting", priority: "high", impact: 8,
          text: `This content exceeds X/Twitter's character limit — needs significant trimming.`,
          reasoning: `X/Twitter allows 280 characters. Your brand's "${brand.voice.tone[2] || "Simple"}" tone style is perfect for this — distill to the single most powerful sentence.`,
          action: "Condense to under 280 characters",
        });
      }
    }

    // Positive feedback where scores are high
    if (scores.voice >= 85) {
      channelSuggestions[ch].push({
        id: `${ch}-pos-v`, dimension: "voice", priority: "none", impact: 0,
        text: `Excellent brand voice alignment — the "${brand.voice.personality[0]}" personality comes through clearly.`,
        reasoning: `The language, sentence structure, and emotional tone closely match your defined brand voice guidelines.`,
        type: "positive",
      });
    }
    if (scores.visual >= 85) {
      channelSuggestions[ch].push({
        id: `${ch}-pos-m`, dimension: "visual", priority: "none", impact: 0,
        text: `Visual identity is strong — brand colors and style are well-represented.`,
        reasoning: `The media aligns well with your brand kit specifications.`,
        type: "positive",
      });
    }
  });

  return {
    overall,
    scores,
    channelSuggestions,
    analyzedAt: new Date().toLocaleTimeString(),
  };
}

/* ════════════════════════════════════════════════════════════════
   UI COMPONENTS
   ════════════════════════════════════════════════════════════════ */

/* ── animated circular gauge ── */
function ScoreGauge({ score, size = 130, strokeWidth = 11 }) {
  const [display, setDisplay] = useState(0);
  const radius = (size - strokeWidth) / 2;
  const circ = 2 * Math.PI * radius;
  const offset = circ - (display / 100) * circ;
  const color = score >= 80 ? T.green : score >= 60 ? T.yellow : T.red;
  const label = score >= 80 ? "On Brand" : score >= 60 ? "Needs Work" : "Off Brand";
  const bg = score >= 80 ? T.greenLt : score >= 60 ? T.yellowLt : T.redLt;

  useEffect(() => {
    let start = Date.now();
    const dur = 1200;
    const tick = () => {
      const p = Math.min((Date.now() - start) / dur, 1);
      setDisplay(Math.round((1 - Math.pow(1 - p, 3)) * score));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [score]);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "8px" }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
          <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={T.gray100} strokeWidth={strokeWidth} />
          <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
            strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontSize: "36px", fontWeight: 700, color: T.gray900, lineHeight: 1 }}>{display}</span>
          <span style={{ fontSize: "12px", color: T.gray500, marginTop: "2px" }}>/100</span>
        </div>
      </div>
      <span style={{ fontSize: "12px", fontWeight: 600, color, background: bg, padding: "3px 12px", borderRadius: "20px" }}>{label}</span>
    </div>
  );
}

/* ── progress bar ── */
function ScoreBar({ score, height = 6 }) {
  const color = score >= 80 ? T.green : score >= 60 ? T.yellow : score >= 40 ? T.orange : T.red;
  return (
    <div style={{ flex: 1, height, background: T.gray100, borderRadius: height, overflow: "hidden" }}>
      <div style={{ width: `${score}%`, height: "100%", background: color, borderRadius: height, transition: "width 0.8s ease" }} />
    </div>
  );
}

/* ── tag/pill component ── */
function Pill({ children, color = T.blue, bg = T.blueLt, onRemove, onClick, selected }) {
  return (
    <span onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: "4px", padding: "3px 10px",
      borderRadius: "14px", fontSize: "12px", fontWeight: 500, color,
      background: selected ? color : bg,
      ...(selected && { color: T.white }),
      cursor: onClick ? "pointer" : "default", transition: "all 0.15s",
      border: onClick ? `1px solid ${selected ? color : "transparent"}` : "none",
    }}>
      {children}
      {onRemove && <X size={12} style={{ cursor: "pointer", marginLeft: "2px" }} onClick={(e) => { e.stopPropagation(); onRemove(); }} />}
    </span>
  );
}

/* ── button component ── */
function Btn({ children, variant = "primary", size = "md", onClick, style: sx, disabled, ...props }) {
  const base = { display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "6px", border: "none", cursor: disabled ? "default" : "pointer", fontFamily: T.font, fontWeight: 600, borderRadius: T.radiusSm, transition: "all 0.15s", opacity: disabled ? 0.5 : 1 };
  const sizes = { sm: { padding: "5px 12px", fontSize: "12px" }, md: { padding: "8px 18px", fontSize: "13px" }, lg: { padding: "10px 24px", fontSize: "14px" } };
  const variants = {
    primary: { background: T.blue, color: T.white },
    secondary: { background: T.white, color: T.gray700, border: `1px solid ${T.gray200}` },
    ghost: { background: "transparent", color: T.blue },
    danger: { background: T.redLt, color: T.red },
  };
  return <button onClick={disabled ? undefined : onClick} style={{ ...base, ...sizes[size], ...variants[variant], ...sx }} {...props}>{children}</button>;
}

/* ── dropdown select ── */
function Select({ value, options, onChange, placeholder, style: sx }) {
  return (
    <div style={{ position: "relative", ...sx }}>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        width: "100%", padding: "9px 32px 9px 14px", fontSize: "13px", color: value ? T.gray800 : T.gray400,
        border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, background: T.white,
        appearance: "none", cursor: "pointer", fontFamily: T.font,
      }}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o => <option key={o.value || o} value={o.value || o}>{o.label || o}</option>)}
      </select>
      <ChevronDown size={16} color={T.gray400} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
    </div>
  );
}

/* ── color swatch picker ── */
function ColorSwatch({ color, size = 28, onClick, label }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
      {label && <span style={{ fontSize: "11px", color: T.gray500 }}>{label}</span>}
      <div onClick={onClick} style={{
        width: size, height: size, borderRadius: T.radiusSm, background: color,
        border: `2px solid ${T.gray200}`, cursor: onClick ? "pointer" : "default",
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)",
      }} />
    </div>
  );
}

/* ── multi-select tag input ── */
function TagInput({ selected, options, onChange, placeholder }) {
  const [open, setOpen] = useState(false);
  const available = options.filter(o => !selected.includes(o));
  return (
    <div style={{ position: "relative" }}>
      <div onClick={() => setOpen(!open)} style={{
        display: "flex", flexWrap: "wrap", gap: "4px", padding: "6px 10px",
        border: `1px solid ${open ? T.blue : T.gray200}`, borderRadius: T.radiusSm,
        background: T.white, cursor: "pointer", minHeight: "38px", alignItems: "center",
      }}>
        {selected.map(s => (
          <Pill key={s} color={T.blue} bg={T.blueLt} onRemove={() => onChange(selected.filter(x => x !== s))}>{s}</Pill>
        ))}
        {selected.length === 0 && <span style={{ fontSize: "13px", color: T.gray400 }}>{placeholder}</span>}
        <ChevronDown size={14} color={T.gray400} style={{ marginLeft: "auto" }} />
      </div>
      {open && available.length > 0 && (
        <div style={{ position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 50, background: T.white, border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, boxShadow: T.shadowLg, maxHeight: "200px", overflow: "auto" }}>
          {available.map(o => (
            <div key={o} onClick={() => { onChange([...selected, o]); }} style={{ padding: "8px 14px", fontSize: "13px", color: T.gray700, cursor: "pointer" }}
              onMouseOver={e => e.currentTarget.style.background = T.gray50}
              onMouseOut={e => e.currentTarget.style.background = T.white}
            >{o}</div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   SUGGESTION CARD — with reasoning, examples, per-channel
   ════════════════════════════════════════════════════════════════ */
function SuggestionCard({ s, applied, onApply }) {
  const [showDetail, setShowDetail] = useState(false);
  const isPositive = s.type === "positive";
  const prioStyle = { high: { bg: T.redLt, color: T.red, label: "High Impact" }, medium: { bg: T.yellowLt, color: T.yellow, label: "Medium" }, low: { bg: T.gray100, color: T.gray500, label: "Low" }, none: { bg: T.greenLt, color: T.green, label: "" } };
  const ps = prioStyle[s.priority] || prioStyle.low;

  return (
    <div style={{
      borderRadius: T.radiusSm, background: applied ? T.greenLt : isPositive ? T.greenLt : T.white,
      border: `1px solid ${applied ? "#BBF7D0" : isPositive ? "#BBF7D0" : T.gray200}`,
      overflow: "hidden", transition: "all 0.2s", opacity: applied ? 0.75 : 1,
    }}>
      <div style={{ padding: "10px 12px" }}>
        <div style={{ display: "flex", gap: "8px" }}>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: "13px", color: T.gray700, lineHeight: "19px", margin: 0 }}>
              {isPositive && <CheckCircle2 size={13} color={T.green} style={{ marginRight: 4, verticalAlign: "middle" }} />}
              {s.text}
            </p>
            <div style={{ display: "flex", gap: "6px", marginTop: "6px", alignItems: "center", flexWrap: "wrap" }}>
              {s.priority !== "none" && (
                <span style={{ fontSize: "11px", fontWeight: 500, color: ps.color, background: ps.bg, padding: "1px 7px", borderRadius: "4px" }}>{ps.label}</span>
              )}
              {s.impact > 0 && <span style={{ fontSize: "11px", color: T.green, fontWeight: 600 }}>+{s.impact} pts</span>}
              {(s.reasoning || s.example) && (
                <button onClick={() => setShowDetail(!showDetail)} style={{ fontSize: "11px", color: T.blue, background: "none", border: "none", cursor: "pointer", fontWeight: 500, padding: 0 }}>
                  {showDetail ? "Hide reasoning" : "Why this matters?"}
                </button>
              )}
            </div>
          </div>
          {!isPositive && !applied && (
            <Btn variant="secondary" size="sm" onClick={() => onApply(s.id)} style={{ alignSelf: "flex-start", flexShrink: 0, color: T.blue, fontWeight: 500 }}>Apply</Btn>
          )}
          {applied && (
            <div style={{ alignSelf: "center", display: "flex", alignItems: "center", gap: "3px", color: T.green, fontSize: "12px", fontWeight: 500, flexShrink: 0 }}>
              <Check size={14} /> Done
            </div>
          )}
        </div>
      </div>

      {/* Expandable reasoning section */}
      {showDetail && (
        <div style={{ padding: "0 12px 12px", borderTop: `1px solid ${T.gray100}`, marginTop: "0" }}>
          {s.reasoning && (
            <div style={{ marginTop: "8px", padding: "8px 10px", background: T.gray50, borderRadius: "4px", borderLeft: `3px solid ${T.blue}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: "4px", marginBottom: "4px" }}>
                <Lightbulb size={12} color={T.blue} />
                <span style={{ fontSize: "11px", fontWeight: 600, color: T.blue }}>Why this matters</span>
              </div>
              <p style={{ fontSize: "12px", color: T.gray600, lineHeight: "17px", margin: 0 }}>{s.reasoning}</p>
            </div>
          )}
          {s.action && (
            <div style={{ marginTop: "6px", display: "flex", alignItems: "flex-start", gap: "4px" }}>
              <ArrowRight size={12} color={T.green} style={{ marginTop: "2px", flexShrink: 0 }} />
              <span style={{ fontSize: "12px", color: T.gray700, fontWeight: 500 }}>{s.action}</span>
            </div>
          )}
          {s.example && (
            <div style={{ marginTop: "6px", padding: "6px 10px", background: T.purpleLt, borderRadius: "4px" }}>
              <span style={{ fontSize: "11px", color: T.purple, fontWeight: 500 }}>💡 Example: </span>
              <span style={{ fontSize: "12px", color: T.gray600, fontStyle: "italic" }}>{s.example}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   SCORING CRITERIA EDITOR
   ════════════════════════════════════════════════════════════════ */
function CriteriaEditor({ criteria, onChange, onClose }) {
  const [local, setLocal] = useState(criteria.map(c => ({ ...c })));
  const totalWeight = local.filter(c => c.enabled).reduce((a, c) => a + c.weight, 0);

  const update = (id, field, value) => {
    setLocal(prev => prev.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.4)" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ width: "480px", maxHeight: "80vh", background: T.white, borderRadius: T.radiusLg, boxShadow: T.shadowLg, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "20px 24px", borderBottom: `1px solid ${T.gray200}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: "16px", fontWeight: 600, color: T.gray900 }}>Scoring Criteria</h3>
            <p style={{ margin: "4px 0 0", fontSize: "12px", color: T.gray500 }}>Customize which dimensions matter and their weight</p>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer" }}><X size={20} color={T.gray400} /></button>
        </div>
        <div style={{ padding: "16px 24px", overflow: "auto", flex: 1 }}>
          {totalWeight !== 100 && (
            <div style={{ padding: "8px 12px", background: T.yellowLt, borderRadius: T.radiusSm, marginBottom: "12px", display: "flex", alignItems: "center", gap: "6px" }}>
              <AlertTriangle size={14} color={T.yellow} />
              <span style={{ fontSize: "12px", color: T.gray700 }}>Weights should total 100%. Current: {totalWeight}%</span>
            </div>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {local.map(c => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "10px 12px", background: c.enabled ? T.white : T.gray50, border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, opacity: c.enabled ? 1 : 0.6 }}>
                <input type="checkbox" checked={c.enabled} onChange={e => update(c.id, "enabled", e.target.checked)} style={{ accentColor: T.blue }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{c.label}</div>
                  <div style={{ fontSize: "11px", color: T.gray500 }}>{c.description}</div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <input type="range" min={0} max={50} value={c.weight} disabled={!c.enabled}
                    onChange={e => update(c.id, "weight", parseInt(e.target.value))}
                    style={{ width: "80px", accentColor: T.blue }} />
                  <span style={{ fontSize: "13px", fontWeight: 600, color: T.gray700, minWidth: "32px", textAlign: "right" }}>{c.weight}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ padding: "16px 24px", borderTop: `1px solid ${T.gray200}`, display: "flex", gap: "8px", justifyContent: "flex-end" }}>
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
          <Btn variant="primary" onClick={() => { onChange(local); onClose(); }} disabled={totalWeight !== 100}>Save Criteria</Btn>
        </div>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   LEFT SIDEBAR NAV
   ════════════════════════════════════════════════════════════════ */
function LeftNav({ activePage, onNavigate }) {
  const items = [
    { key: "home", icon: <Home size={18} /> },
    { key: "inbox", icon: <Mail size={18} /> },
    { key: "calendar", icon: <Calendar size={18} /> },
    { key: "star", icon: <Star size={18} /> },
    { key: "mentions", icon: <Megaphone size={18} /> },
    { key: "analytics", icon: <BarChart3 size={18} /> },
    { key: "social", icon: <Users size={18} /> },
    { key: "reviews", icon: <BookOpen size={18} /> },
    { key: "insights", icon: <Layout size={18} /> },
    { key: "competitors", icon: <Target size={18} /> },
    { key: "contacts", icon: <Users size={18} /> },
    { key: "settings", icon: <Settings size={18} /> },
  ];
  return (
    <div style={{ width: "48px", background: T.white, borderRight: `1px solid ${T.gray200}`, display: "flex", flexDirection: "column", alignItems: "center", paddingTop: "8px", gap: "2px", flexShrink: 0 }}>
      {items.map(item => {
        const active = item.key === activePage || (activePage === "createpost" && item.key === "social") || (activePage === "brand-identity" && item.key === "settings");
        return (
          <button key={item.key} onClick={() => onNavigate(item.key === "social" ? "createpost" : item.key === "settings" ? "brand-identity" : item.key)} style={{
            width: 36, height: 36, borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center",
            background: active ? T.blueLt : "transparent", color: active ? T.blue : T.gray400,
            border: "none", cursor: "pointer", transition: "all 0.15s",
          }}>{item.icon}</button>
        );
      })}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   TOP NAV BAR
   ════════════════════════════════════════════════════════════════ */
function TopNav({ onSettings }) {
  return (
    <div style={{ height: "48px", background: T.white, borderBottom: `1px solid ${T.gray200}`, display: "flex", alignItems: "center", padding: "0 16px", zIndex: 30, flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
        <div style={{ width: 26, height: 26, borderRadius: "6px", background: T.blue, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: T.white, fontSize: "15px", fontWeight: 800 }}>B</span>
        </div>
        <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray800 }}>Social AI</span>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
        <button style={{ width: 28, height: 28, borderRadius: "50%", background: T.blue, border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><Plus size={14} color={T.white} /></button>
        <button style={{ width: 28, height: 28, borderRadius: "50%", background: T.gray100, border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><HelpCircle size={14} color={T.gray500} /></button>
        <button onClick={onSettings} style={{ width: 28, height: 28, borderRadius: "50%", background: T.gray100, border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><Settings size={14} color={T.gray500} /></button>
        <div style={{ width: 28, height: 28, borderRadius: "50%", background: T.blue, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: T.white, fontSize: "11px", fontWeight: 700 }}>PG</span>
        </div>
        <button style={{ width: 28, height: 28, borderRadius: "50%", background: T.gray100, border: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
          <div style={{ width: 14, height: 2, background: T.gray500, position: "relative" }}>
            <div style={{ width: 14, height: 2, background: T.gray500, position: "absolute", top: -5 }} />
            <div style={{ width: 14, height: 2, background: T.gray500, position: "absolute", top: 5 }} />
          </div>
        </button>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   BRAND IDENTITY SETTINGS PAGE
   ════════════════════════════════════════════════════════════════ */
function BrandIdentityPage({ brands, setBrands, onNavigate }) {
  const [selectedBrand, setSelectedBrand] = useState(null);
  const [scraping, setScraping] = useState(false);
  const [scrapeUrl, setScrapeUrl] = useState("");
  const [scrapeProgress, setScrapeProgress] = useState(0);
  const [activeTab, setActiveTab] = useState("identity"); // identity | guardrails

  const handleScrape = () => {
    if (!scrapeUrl) return;
    setScraping(true);
    setScrapeProgress(0);
    const steps = [10, 25, 45, 65, 80, 95, 100];
    steps.forEach((p, i) => {
      setTimeout(() => {
        setScrapeProgress(p);
        if (p === 100) {
          setTimeout(() => setScraping(false), 500);
        }
      }, (i + 1) * 600);
    });
  };

  // List view
  if (!selectedBrand) {
    return (
      <div style={{ flex: 1, overflow: "auto", background: T.white }}>
        <div style={{ padding: "0 32px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "16px 0", fontSize: "13px", color: T.gray500 }}>
            <span style={{ color: T.blue, cursor: "pointer" }} onClick={() => onNavigate("settings")}>Settings</span>
            <ChevronRight size={14} />
            <span style={{ color: T.blue, cursor: "pointer" }}>BirdAI</span>
            <ChevronRight size={14} />
            <span style={{ color: T.gray800, fontWeight: 500 }}>Brand Identity</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "24px" }}>
            <h1 style={{ fontSize: "22px", fontWeight: 600, color: T.gray900, margin: 0 }}>Brand Identity</h1>
            <div style={{ display: "flex", gap: "8px" }}>
              <Btn variant="primary" onClick={() => {
                const newBrand = {
                  id: Date.now(), name: "New Brand", isDefault: false, locations: "All locations",
                  domain: "", logo: "🏢", logoColor: T.blue,
                  voice: { personality: [], tone: [] },
                  kit: { colors: { primary: "#2D68FE", secondary: "#EBF0FF", dark: "#1A1A1A", headerFont: "#FFFFFF", bodyFont: "#1A1A1A", ctaFont: "#FFFFFF" }, fonts: { header: "Inter", headerWeight: "Bold", body: "Inter", bodyWeight: "Regular" }, logos: [] },
                  createdBy: "You", createdOn: new Date().toLocaleDateString("en-US", { year: "numeric", month: "short", day: "2-digit" }),
                };
                setBrands(prev => [...prev, newBrand]);
                setSelectedBrand(newBrand);
              }}>
                <span style={{ fontSize: "15px" }}>+</span> Create new
              </Btn>
            </div>
          </div>

          {/* Table */}
          <div style={{ border: `1px solid ${T.gray200}`, borderRadius: T.radius, overflow: "hidden" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
              <thead>
                <tr style={{ background: T.gray50 }}>
                  {["Name", "Locations", "Logo", "Colors", "Voice", "Created by", "Created on"].map(h => (
                    <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontWeight: 500, color: T.gray500, borderBottom: `1px solid ${T.gray200}`, fontSize: "12px" }}>
                      {h} {(h === "Name" || h === "Created by" || h === "Created on") && <span style={{ fontSize: "10px" }}>▴</span>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {brands.map(b => (
                  <tr key={b.id} onClick={() => setSelectedBrand(b)} style={{ cursor: "pointer", borderBottom: `1px solid ${T.gray100}` }}
                    onMouseOver={e => e.currentTarget.style.background = T.gray50}
                    onMouseOut={e => e.currentTarget.style.background = T.white}
                  >
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                        <span style={{ fontWeight: 500, color: T.gray800 }}>{b.name}</span>
                        {b.isDefault && <span style={{ fontSize: "11px", padding: "1px 8px", borderRadius: "4px", background: T.gray100, color: T.gray600 }}>Default</span>}
                      </div>
                    </td>
                    <td style={{ padding: "14px 16px", color: T.gray600 }}>{b.locations}</td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ width: 24, height: 24, borderRadius: "4px", background: b.logoColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px" }}>{b.logo}</div>
                    </td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                        <div style={{ width: 20, height: 20, borderRadius: "50%", background: b.kit.colors.primary, border: `1px solid ${T.gray200}` }} />
                        <div style={{ width: 20, height: 20, borderRadius: "50%", background: b.kit.colors.secondary || b.kit.colors.dark, border: `1px solid ${T.gray200}` }} />
                        <span style={{ fontSize: "12px", color: T.gray500 }}>+2</span>
                      </div>
                    </td>
                    <td style={{ padding: "14px 16px", color: T.gray600 }}>
                      {b.voice.personality[0] || "—"}{b.voice.personality.length > 1 ? `, +${b.voice.personality.length - 1} more` : ""}
                    </td>
                    <td style={{ padding: "14px 16px", color: T.gray600 }}>{b.createdBy}</td>
                    <td style={{ padding: "14px 16px", color: T.gray600 }}>{b.createdOn}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // Detail/edit view
  const updateBrand = (field, value) => {
    const updated = { ...selectedBrand, ...( typeof field === "string" ? { [field]: value } : field ) };
    setSelectedBrand(updated);
    setBrands(prev => prev.map(b => b.id === updated.id ? updated : b));
  };

  return (
    <div style={{ flex: 1, overflow: "auto", background: T.white }}>
      <div style={{ padding: "0 32px" }}>
        {/* Breadcrumb */}
        <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "16px 0", fontSize: "13px", color: T.gray500 }}>
          <span style={{ color: T.blue, cursor: "pointer" }} onClick={() => onNavigate("settings")}>Settings</span>
          <ChevronRight size={14} />
          <span style={{ color: T.blue, cursor: "pointer" }} onClick={() => setSelectedBrand(null)}>Brand Identity</span>
          <ChevronRight size={14} />
          <span style={{ color: T.gray800, fontWeight: 500 }}>{selectedBrand.name}</span>
        </div>

        {/* Title row */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <h1 style={{ fontSize: "22px", fontWeight: 600, color: T.gray900, margin: 0 }}>{selectedBrand.name}</h1>
            <Edit3 size={16} color={T.gray400} style={{ cursor: "pointer" }} />
          </div>
          <Btn variant="secondary" onClick={() => setSelectedBrand(null)}>Save</Btn>
        </div>
        <span style={{ fontSize: "13px", color: T.blue, cursor: "pointer" }}>{selectedBrand.locations}</span>

        {/* Tabs */}
        <div style={{ display: "flex", gap: "0", borderBottom: `2px solid ${T.gray200}`, marginTop: "20px", marginBottom: "24px" }}>
          {["identity", "guardrails"].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)} style={{
              padding: "10px 20px", fontSize: "14px", fontWeight: activeTab === tab ? 600 : 400,
              color: activeTab === tab ? T.blue : T.gray500, background: "none", border: "none",
              borderBottom: activeTab === tab ? `2px solid ${T.blue}` : "2px solid transparent",
              cursor: "pointer", marginBottom: "-2px", textTransform: "capitalize",
            }}>{tab === "identity" ? "Brand Identity" : "Guardrails"}</button>
          ))}
        </div>

        <div style={{ display: "flex", gap: "32px" }}>
          {/* Left: edit form */}
          <div style={{ flex: 1, maxWidth: "600px", display: "flex", flexDirection: "column", gap: "28px", paddingBottom: "40px" }}>

            {/* Sources */}
            <div>
              <h3 style={{ fontSize: "16px", fontWeight: 600, color: T.gray900, margin: "0 0 4px" }}>Sources</h3>
              <p style={{ fontSize: "13px", color: T.gray500, margin: "0 0 16px" }}>Add your company website url or other options to import brand voice and kit</p>
              <div style={{ display: "flex", alignItems: "center", gap: "4px", marginBottom: "8px" }}>
                <span style={{ fontSize: "13px", fontWeight: 500, color: T.gray700 }}>Company URL</span>
                <span style={{ fontSize: "12px", color: T.blue, background: T.blueLt, padding: "1px 6px", borderRadius: "4px", fontWeight: 500 }}>AI</span>
              </div>
              <div style={{ display: "flex", gap: "8px" }}>
                <div style={{ flex: 1, position: "relative" }}>
                  <input value={scrapeUrl} onChange={e => setScrapeUrl(e.target.value)}
                    placeholder="Enter a URL" style={{
                      width: "100%", padding: "9px 14px", fontSize: "13px", border: `1px solid ${T.gray200}`,
                      borderRadius: T.radiusSm, fontFamily: T.font, outline: "none", boxSizing: "border-box",
                    }}
                    onFocus={e => e.target.style.borderColor = T.blue}
                    onBlur={e => e.target.style.borderColor = T.gray200}
                  />
                </div>
                <Btn variant={scrapeUrl ? "primary" : "secondary"} onClick={handleScrape} disabled={!scrapeUrl || scraping}>
                  {scraping ? "Importing..." : "Import"}
                </Btn>
              </div>

              {scraping && (
                <div style={{ marginTop: "12px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                    <span style={{ fontSize: "12px", color: T.gray600 }}>
                      {scrapeProgress < 30 ? "Scraping website..." : scrapeProgress < 60 ? "Analyzing brand voice..." : scrapeProgress < 90 ? "Extracting brand kit..." : "Finalizing..."}
                    </span>
                    <span style={{ fontSize: "12px", fontWeight: 600, color: T.blue }}>{scrapeProgress}%</span>
                  </div>
                  <div style={{ height: "4px", background: T.gray100, borderRadius: "4px", overflow: "hidden" }}>
                    <div style={{ width: `${scrapeProgress}%`, height: "100%", background: T.blue, borderRadius: "4px", transition: "width 0.4s ease" }} />
                  </div>
                </div>
              )}

              <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
                <span style={{ fontSize: "13px", color: T.gray500 }}>Add</span>
                <span style={{ fontSize: "13px", color: T.blue, cursor: "pointer", fontWeight: 500 }}>PDF</span>
                <span style={{ fontSize: "13px", color: T.gray500 }}>or paste your</span>
                <span style={{ fontSize: "13px", color: T.blue, cursor: "pointer", fontWeight: 500 }}>text</span>
              </div>
            </div>

            {/* Brand Voice */}
            <div>
              <h3 style={{ fontSize: "16px", fontWeight: 600, color: T.gray900, margin: "0 0 4px" }}>Brand voice</h3>
              <p style={{ fontSize: "13px", color: T.gray500, margin: "0 0 16px" }}>Your brand personality & tone</p>

              <div style={{ marginBottom: "16px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
                  <span style={{ fontSize: "13px", fontWeight: 500, color: T.gray700 }}>Brand personality</span>
                  <HelpCircle size={14} color={T.gray400} />
                </div>
                <TagInput selected={selectedBrand.voice.personality} options={PERSONALITY_OPTIONS}
                  onChange={val => updateBrand({ voice: { ...selectedBrand.voice, personality: val } })}
                  placeholder="Select personality traits" />
              </div>

              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
                  <span style={{ fontSize: "13px", fontWeight: 500, color: T.gray700 }}>Tone and writing style</span>
                  <HelpCircle size={14} color={T.gray400} />
                </div>
                <TagInput selected={selectedBrand.voice.tone} options={TONE_OPTIONS}
                  onChange={val => updateBrand({ voice: { ...selectedBrand.voice, tone: val } })}
                  placeholder="Select tone attributes" />
              </div>
            </div>

            {/* Brand Kit */}
            <div>
              <h3 style={{ fontSize: "16px", fontWeight: 600, color: T.gray900, margin: "0 0 4px" }}>Brand kit</h3>
              <p style={{ fontSize: "13px", color: T.gray500, margin: "0 0 16px" }}>Your brand logos, fonts & colors</p>

              {/* Logos */}
              <div style={{ marginBottom: "20px" }}>
                <div style={{ fontSize: "13px", fontWeight: 500, color: T.gray700, marginBottom: "8px" }}>Logos <span style={{ color: T.red }}>*</span></div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <div style={{ width: 88, height: 88, borderRadius: T.radius, background: T.greenLt, border: `2px solid ${T.green}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "36px" }}>
                    {selectedBrand.logo}
                  </div>
                  <div style={{ width: 88, height: 88, borderRadius: T.radius, border: `2px dashed ${T.gray300}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                    <Plus size={20} color={T.gray400} />
                  </div>
                </div>
                <Select value="light" options={[{value: "light", label: "Light background"}, {value: "dark", label: "Dark background"}]} onChange={() => {}} style={{ width: "160px", marginTop: "8px" }} />
              </div>

              {/* Fonts */}
              <div style={{ marginBottom: "20px" }}>
                <div style={{ fontSize: "13px", fontWeight: 500, color: T.gray700, marginBottom: "12px" }}>Fonts</div>
                <div style={{ display: "flex", gap: "16px" }}>
                  <div style={{ flex: 1 }}>
                    <span style={{ fontSize: "12px", color: T.gray500, display: "block", marginBottom: "6px" }}>Header</span>
                    <Select value={selectedBrand.kit.fonts.header} options={FONT_OPTIONS} onChange={v => updateBrand({ kit: { ...selectedBrand.kit, fonts: { ...selectedBrand.kit.fonts, header: v } } })} />
                    <Select value={selectedBrand.kit.fonts.headerWeight} options={["Bold", "Semi-Bold", "Regular", "Light"]} onChange={v => updateBrand({ kit: { ...selectedBrand.kit, fonts: { ...selectedBrand.kit.fonts, headerWeight: v } } })} style={{ marginTop: "6px" }} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <span style={{ fontSize: "12px", color: T.gray500, display: "block", marginBottom: "6px" }}>Body</span>
                    <Select value={selectedBrand.kit.fonts.body} options={FONT_OPTIONS} onChange={v => updateBrand({ kit: { ...selectedBrand.kit, fonts: { ...selectedBrand.kit.fonts, body: v } } })} />
                    <Select value={selectedBrand.kit.fonts.bodyWeight} options={["Bold", "Semi-Bold", "Regular", "Light"]} onChange={v => updateBrand({ kit: { ...selectedBrand.kit, fonts: { ...selectedBrand.kit.fonts, bodyWeight: v } } })} style={{ marginTop: "6px" }} />
                  </div>
                </div>
              </div>

              {/* Colors */}
              <div>
                <div style={{ fontSize: "13px", fontWeight: 500, color: T.gray700, marginBottom: "12px" }}>Colors</div>
                <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                  {Object.entries(selectedBrand.kit.colors).map(([key, val]) => (
                    <div key={key} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
                      <span style={{ fontSize: "11px", color: T.gray500, textTransform: "capitalize" }}>{key.replace(/([A-Z])/g, " $1").trim()}</span>
                      <div style={{ display: "flex", alignItems: "center", gap: "4px", padding: "4px 8px", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm }}>
                        <div style={{ width: 22, height: 22, borderRadius: "4px", background: val, border: "1px solid rgba(0,0,0,0.1)" }} />
                        <ChevronDown size={12} color={T.gray400} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right: preview */}
          <div style={{ width: "380px", flexShrink: 0 }}>
            <div style={{ position: "sticky", top: "20px", background: T.gray50, borderRadius: T.radius, padding: "20px", border: `1px solid ${T.gray200}` }}>
              <h4 style={{ fontSize: "14px", fontWeight: 600, color: T.gray800, margin: "0 0 4px" }}>Preview</h4>
              <p style={{ fontSize: "12px", color: T.gray500, margin: "0 0 16px" }}>Here are some samples of review responses, social posts & emails generated with your brand voice & kit</p>

              <div style={{ marginBottom: "12px" }}>
                <span style={{ fontSize: "12px", fontWeight: 500, color: T.gray600, display: "block", marginBottom: "8px" }}>Social post</span>
                <div style={{ background: T.white, borderRadius: T.radiusSm, border: `1px solid ${T.gray200}`, padding: "12px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: selectedBrand.logoColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px" }}>{selectedBrand.logo}</div>
                    <span style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{selectedBrand.name}</span>
                  </div>
                  <p style={{ fontSize: "12px", color: T.gray600, lineHeight: "18px", margin: 0 }}>
                    Welcome to {selectedBrand.name}! We're here to provide you with the best experience.
                    {selectedBrand.voice.personality.length > 0 && ` Our ${selectedBrand.voice.personality[0].toLowerCase()} approach sets us apart.`}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Dimension Accordion (extracted for hooks compliance) ── */
function DimensionAccordion({ criterion, score, suggestions, applied, onApply }) {
  const [exp, setExp] = useState(score < 70);
  const color = score >= 80 ? T.green : score >= 60 ? T.yellow : T.red;
  return (
    <div style={{ borderRadius: T.radiusSm, border: `1px solid ${T.gray200}`, overflow: "hidden", background: T.white }}>
      <button onClick={() => setExp(!exp)} style={{ width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "11px 12px", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "3px" }}>
            <span style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{criterion.label}</span>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <span style={{ fontSize: "11px", color: T.gray400 }}>{criterion.weight}%</span>
              <span style={{ fontSize: "13px", fontWeight: 700, color }}>{score}</span>
            </div>
          </div>
          <ScoreBar score={score} />
        </div>
        <ChevronDown size={14} color={T.gray400} style={{ transform: exp ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.2s" }} />
      </button>
      {exp && suggestions.length > 0 && (
        <div style={{ padding: "0 12px 12px", display: "flex", flexDirection: "column", gap: "6px", borderTop: `1px solid ${T.gray100}` }}>
          <div style={{ height: "8px" }} />
          {suggestions.map(s => (
            <SuggestionCard key={s.id} s={s} applied={applied.has(s.id)} onApply={onApply} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   BRAND SCORE PANEL (right drawer in Create Post)
   ════════════════════════════════════════════════════════════════ */
function BrandScoreDrawer({ open, onClose, brands, postContent, channels, onOpenSettings }) {
  const [selectedBrand, setSelectedBrand] = useState(brands[0]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scoreData, setScoreData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [applied, setApplied] = useState(new Set());
  const [activeTab, setActiveTab] = useState("score");
  const [channelFilter, setChannelFilter] = useState("all");
  const [criteria, setCriteria] = useState(DEFAULT_CRITERIA);
  const [showCriteriaEditor, setShowCriteriaEditor] = useState(false);

  const runScoring = useCallback(() => {
    setLoading(true);
    setApplied(new Set());
    setTimeout(() => {
      setScoreData(generateScores(selectedBrand, postContent, channels, criteria));
      setLoading(false);
    }, 2000);
  }, [selectedBrand, postContent, channels, criteria]);

  useEffect(() => {
    if (open && !scoreData) runScoring();
  }, [open]);

  const handleApply = (id) => setApplied(prev => { const n = new Set(prev); n.add(id); return n; });

  const allSuggestions = useMemo(() => {
    if (!scoreData) return [];
    const ch = channelFilter === "all" ? Object.keys(scoreData.channelSuggestions) : [channelFilter];
    const seen = new Set();
    return ch.flatMap(c => (scoreData.channelSuggestions[c] || []).filter(s => { if (seen.has(s.id)) return false; seen.add(s.id); return true; }));
  }, [scoreData, channelFilter]);

  const actionable = allSuggestions.filter(s => s.type !== "positive");
  const appliedCount = actionable.filter(s => applied.has(s.id)).length;
  const estimatedGain = actionable.filter(s => applied.has(s.id)).reduce((a, s) => a + (s.impact || 0), 0);

  if (!open) return null;

  return (
    <>
      {showCriteriaEditor && <CriteriaEditor criteria={criteria} onChange={c => { setCriteria(c); setScoreData(null); setTimeout(runScoring, 100); }} onClose={() => setShowCriteriaEditor(false)} />}
      <div style={{
        width: "380px", borderLeft: `1px solid ${T.gray200}`, background: T.white,
        display: "flex", flexDirection: "column", flexShrink: 0, overflow: "hidden",
      }}>
        {/* Header */}
        <div style={{ padding: "14px 18px", borderBottom: `1px solid ${T.gray200}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <Shield size={18} color={T.blue} />
            <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray900 }}>Brand Score</span>
          </div>
          <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
            <button onClick={() => setShowCriteriaEditor(true)} title="Scoring criteria" style={{ background: "none", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, padding: "4px", cursor: "pointer", display: "flex" }}
              onMouseOver={e => e.currentTarget.style.background = T.gray50} onMouseOut={e => e.currentTarget.style.background = "none"}>
              <Settings size={14} color={T.gray500} />
            </button>
            <button onClick={() => { setScoreData(null); setTimeout(runScoring, 50); }} title="Re-analyze" style={{ background: "none", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, padding: "4px", cursor: "pointer", display: "flex" }}
              onMouseOver={e => e.currentTarget.style.background = T.gray50} onMouseOut={e => e.currentTarget.style.background = "none"}>
              <RefreshCw size={14} color={T.gray500} />
            </button>
            <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", padding: "4px" }}><X size={18} color={T.gray500} /></button>
          </div>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflow: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: "14px" }}>

          {/* Brand selector */}
          <div>
            <label style={{ fontSize: "12px", fontWeight: 500, color: T.gray500, display: "block", marginBottom: "5px" }}>Brand Identity</label>
            <div style={{ position: "relative" }}>
              <button onClick={() => setDropdownOpen(!dropdownOpen)} style={{
                width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "8px 12px",
                background: T.white, border: `1px solid ${dropdownOpen ? T.blue : T.gray200}`, borderRadius: T.radiusSm, cursor: "pointer", textAlign: "left",
              }}>
                <span style={{ fontSize: "18px" }}>{selectedBrand.logo}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: T.gray800 }}>{selectedBrand.name}</div>
                  <div style={{ fontSize: "11px", color: T.gray500 }}>{selectedBrand.domain || selectedBrand.locations}</div>
                </div>
                <ChevronDown size={16} color={T.gray400} style={{ transform: dropdownOpen ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.2s" }} />
              </button>
              {dropdownOpen && (
                <div style={{ position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, zIndex: 10, background: T.white, border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, boxShadow: T.shadowLg, overflow: "hidden" }}>
                  {brands.map(b => (
                    <button key={b.id} onClick={() => { setSelectedBrand(b); setDropdownOpen(false); setScoreData(null); setTimeout(runScoring, 100); }} style={{
                      width: "100%", display: "flex", alignItems: "center", gap: "10px", padding: "10px 12px",
                      background: b.id === selectedBrand.id ? T.blueLt : "none", border: "none", cursor: "pointer", borderBottom: `1px solid ${T.gray100}`, textAlign: "left",
                    }}>
                      <span style={{ fontSize: "16px" }}>{b.logo}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: "13px", fontWeight: 500, color: T.gray800 }}>{b.name}</div>
                        <div style={{ fontSize: "11px", color: T.gray500 }}>{b.domain || b.locations}</div>
                      </div>
                      {b.id === selectedBrand.id && <Check size={16} color={T.blue} />}
                    </button>
                  ))}
                  <button onClick={() => { setDropdownOpen(false); onOpenSettings(); }} style={{
                    width: "100%", padding: "10px 12px", background: T.gray50, border: "none", cursor: "pointer",
                    fontSize: "12px", color: T.blue, fontWeight: 500, display: "flex", alignItems: "center", gap: "6px",
                  }}><Plus size={14} /> Manage Brand Identities</button>
                </div>
              )}
            </div>
          </div>

          {/* Brand summary */}
          <div style={{ padding: "10px 12px", background: T.gray50, borderRadius: T.radiusSm }}>
            <div style={{ display: "flex", alignItems: "center", gap: "5px", marginBottom: "6px" }}>
              <Shield size={12} color={T.blue} />
              <span style={{ fontSize: "11px", fontWeight: 600, color: T.gray700 }}>Brand Guidelines</span>
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "3px", marginBottom: "6px" }}>
              {selectedBrand.voice.personality.map(p => <Pill key={p} color={T.blue} bg={T.blueLt}>{p}</Pill>)}
              {selectedBrand.voice.tone.map(t => <Pill key={t} color={T.purple} bg={T.purpleLt}>{t}</Pill>)}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <Palette size={11} color={T.gray500} />
              <div style={{ display: "flex", gap: "3px" }}>
                {[selectedBrand.kit.colors.primary, selectedBrand.kit.colors.secondary, selectedBrand.kit.colors.dark].filter(Boolean).map((c, i) => (
                  <div key={i} style={{ width: 14, height: 14, borderRadius: "3px", background: c, border: "1px solid rgba(0,0,0,0.1)" }} />
                ))}
              </div>
              <span style={{ fontSize: "11px", color: T.gray500 }}>{selectedBrand.kit.fonts.header}, {selectedBrand.kit.fonts.body}</span>
            </div>
          </div>

          {/* Loading */}
          {loading && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "40px 20px", gap: "16px" }}>
              <div style={{ width: 48, height: 48, borderRadius: "50%", border: `3px solid ${T.gray200}`, borderTopColor: T.blue, animation: "spin 1s linear infinite" }} />
              <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
              <div style={{ textAlign: "center" }}>
                <p style={{ fontSize: "14px", fontWeight: 500, color: T.gray800, margin: "0 0 4px" }}>Analyzing your post...</p>
                <p style={{ fontSize: "12px", color: T.gray500, margin: 0 }}>Checking content, media, CTAs & hashtags against "{selectedBrand.name}" guidelines</p>
              </div>
            </div>
          )}

          {/* Results */}
          {!loading && scoreData && (
            <>
              {/* Gauge */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "4px 0" }}>
                <ScoreGauge score={scoreData.overall} />
                <p style={{ fontSize: "12px", color: T.gray500, marginTop: "6px", textAlign: "center", lineHeight: "17px" }}>
                  Your post is <strong style={{ color: T.gray700 }}>{scoreData.overall >= 80 ? "well aligned" : scoreData.overall >= 60 ? "partially aligned" : "not aligned"}</strong> with {selectedBrand.name}
                  {appliedCount > 0 && <><br /><span style={{ color: T.green }}>Estimated gain: +{estimatedGain} pts after applying {appliedCount} suggestions</span></>}
                </p>
              </div>

              {/* Tab switcher */}
              <div style={{ display: "flex", background: T.gray100, borderRadius: T.radiusSm, padding: "3px" }}>
                {[{ key: "score", label: "Breakdown" }, { key: "suggestions", label: `Suggestions (${actionable.length})` }].map(tab => (
                  <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
                    flex: 1, padding: "7px 10px", fontSize: "12px", fontWeight: 500,
                    background: activeTab === tab.key ? T.white : "transparent",
                    color: activeTab === tab.key ? T.gray800 : T.gray500,
                    border: "none", borderRadius: "4px", cursor: "pointer",
                    boxShadow: activeTab === tab.key ? T.shadow : "none",
                  }}>{tab.label}</button>
                ))}
              </div>

              {/* Channel filter */}
              {channels.length > 1 && (
                <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
                  <Pill onClick={() => setChannelFilter("all")} selected={channelFilter === "all"} color={T.blue} bg={T.blueLt}>All Channels</Pill>
                  {channels.map(ch => (
                    <Pill key={ch} onClick={() => setChannelFilter(ch)} selected={channelFilter === ch} color={T.blue} bg={T.blueLt}>
                      <ChannelIcon type={ch} size={12} /> <span style={{ textTransform: "capitalize" }}>{ch}</span>
                    </Pill>
                  ))}
                </div>
              )}

              {/* Score breakdown tab */}
              {activeTab === "score" && (
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {criteria.filter(c => c.enabled).map(c => (
                    <DimensionAccordion key={c.id} criterion={c} score={scoreData.scores[c.id] || 70}
                      suggestions={allSuggestions.filter(s => s.dimension === c.id)}
                      applied={applied} onApply={handleApply} />
                  ))}
                </div>
              )}

              {/* Suggestions tab */}
              {activeTab === "suggestions" && (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {appliedCount > 0 && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 10px", background: T.greenLt, borderRadius: T.radiusSm }}>
                      <TrendingUp size={13} color={T.green} />
                      <span style={{ fontSize: "12px", color: T.greenDk, fontWeight: 500 }}>
                        {appliedCount}/{actionable.length} applied — est. +{estimatedGain} pts improvement
                      </span>
                    </div>
                  )}
                  {allSuggestions.map(s => (
                    <div key={s.id}>
                      <div style={{ display: "flex", alignItems: "center", gap: "5px", marginBottom: "3px" }}>
                        <span style={{ fontSize: "10px", fontWeight: 600, color: T.gray400, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                          {criteria.find(c => c.id === s.dimension)?.label || s.dimension}
                        </span>
                      </div>
                      <SuggestionCard s={s} applied={applied.has(s.id)} onApply={handleApply} />
                    </div>
                  ))}
                </div>
              )}

              {/* Apply all */}
              {appliedCount < actionable.length && (
                <Btn variant="primary" style={{ width: "100%" }} onClick={() => actionable.forEach(s => handleApply(s.id))}>
                  <Zap size={14} /> Apply All Suggestions
                </Btn>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}


/* ════════════════════════════════════════════════════════════════
   CREATE POST PAGE
   ════════════════════════════════════════════════════════════════ */
function CreatePostPage({ brands, onNavigate }) {
  const [postContent, setPostContent] = useState(
    "Nothing beats a freshly grilled burger stacked with juicy patties, soft buns, and bold flavors in every bite. At our shop, we keep it simple—real ingredients, perfect grills, and burgers made to satisfy serious cravings. From the first bite to the last crumb, it's comfort, indulgence, and happiness all wrapped in one burger. Come hungry, eat happy, and leave planning your next visit. 🍔🔥"
  );
  const [channels, setChannels] = useState(["facebook", "instagram", "linkedin"]);
  const [panelOpen, setPanelOpen] = useState(false);
  const [activeEditorTab, setActiveEditorTab] = useState("Initial content");
  const maxChars = 500;

  const removeChannel = (ch) => setChannels(prev => prev.filter(c => c !== ch));

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ height: "56px", background: T.white, borderBottom: `1px solid ${T.gray200}`, display: "flex", alignItems: "center", padding: "0 24px", gap: "12px", flexShrink: 0 }}>
        <button onClick={() => onNavigate("home")} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", color: T.gray600 }}>
          <ArrowLeft size={18} />
        </button>
        <span style={{ fontSize: "15px", fontWeight: 600, color: T.gray900 }}>Create post</span>
        <div style={{ flex: 1 }} />

        {/* BRAND SCORE TRIGGER */}
        <button onClick={() => setPanelOpen(!panelOpen)} style={{
          display: "flex", alignItems: "center", gap: "6px", padding: "7px 14px",
          background: panelOpen ? T.blueLt : T.white, border: `1px solid ${panelOpen ? T.blue : T.gray200}`,
          borderRadius: T.radiusSm, cursor: "pointer", transition: "all 0.2s",
        }}
          onMouseOver={e => { if (!panelOpen) { e.currentTarget.style.borderColor = T.blue; e.currentTarget.style.background = T.blueLt; }}}
          onMouseOut={e => { if (!panelOpen) { e.currentTarget.style.borderColor = T.gray200; e.currentTarget.style.background = T.white; }}}
        >
          <Shield size={15} color={T.blue} />
          <span style={{ fontSize: "13px", fontWeight: 500, color: panelOpen ? T.blue : T.gray700 }}>Brand Score</span>
        </button>

        <label style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: T.gray600 }}>
          <div style={{ width: 18, height: 18, borderRadius: "4px", background: T.white, border: `2px solid ${T.gray300}`, display: "flex", alignItems: "center", justifyContent: "center" }} />
          Add post to library
          <HelpCircle size={14} color={T.gray400} />
        </label>

        <div style={{ display: "flex" }}>
          <Btn variant="primary" style={{ borderRadius: "6px 0 0 6px" }}>Schedule post</Btn>
          <button style={{ padding: "8px 8px", background: T.blueHover, color: T.white, border: "none", borderLeft: `1px solid rgba(255,255,255,0.2)`, borderRadius: "0 6px 6px 0", cursor: "pointer", display: "flex", alignItems: "center" }}>
            <ChevronDown size={14} />
          </button>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* Left: composer */}
        <div style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "20px 24px" }}>

          {/* Channel pills */}
          <div style={{ display: "flex", alignItems: "center", gap: "6px", flexWrap: "wrap", marginBottom: "12px" }}>
            {channels.map(ch => (
              <span key={ch} style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "5px 12px", background: T.gray50, borderRadius: "18px", fontSize: "13px", color: T.gray700, border: `1px solid ${T.gray200}` }}>
                <ChannelIcon type={ch} />
                <span style={{ textTransform: "capitalize" }}>{ch === "facebook" ? "2 pages" : ch === "linkedin" ? "1 page" : ch}</span>
                <X size={13} color={T.gray400} style={{ cursor: "pointer" }} onClick={() => removeChannel(ch)} />
              </span>
            ))}
            <button style={{ display: "flex", alignItems: "center", color: T.gray400, background: "none", border: "none", cursor: "pointer" }}>
              <ChevronDown size={16} />
            </button>
          </div>

          {/* Editor tabs */}
          <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, marginBottom: "16px" }}>
            <div style={{ display: "flex", borderBottom: `2px solid ${T.gray200}` }}>
              {["Initial content", "Facebook", "LinkedIn"].map(tab => (
                <button key={tab} onClick={() => setActiveEditorTab(tab)} style={{
                  padding: "10px 16px", fontSize: "13px", fontWeight: activeEditorTab === tab ? 600 : 400,
                  color: activeEditorTab === tab ? T.blue : T.gray500, background: "none", border: "none",
                  borderBottom: activeEditorTab === tab ? `2px solid ${T.blue}` : "2px solid transparent",
                  cursor: "pointer", marginBottom: "-2px",
                }}>{tab}</button>
              ))}
            </div>
            <div style={{ padding: "0" }}>
              <textarea value={postContent} onChange={e => setPostContent(e.target.value)} style={{
                width: "100%", minHeight: "140px", padding: "16px", border: "none", outline: "none",
                fontSize: "14px", color: T.gray800, lineHeight: "22px", resize: "vertical",
                fontFamily: T.font, boxSizing: "border-box",
              }} placeholder="What would you like to share?" />
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 16px", borderTop: `1px solid ${T.gray100}` }}>
                <div style={{ display: "flex", gap: "10px" }}>
                  <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex" }}><Camera size={18} color={T.gray500} /></button>
                  <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex" }}><Smile size={18} color={T.gray500} /></button>
                  <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex" }}><Copy size={18} color={T.gray500} /></button>
                  <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex", padding: "2px 4px", borderRadius: "4px", background: `linear-gradient(135deg, ${T.blue}, ${T.purple})` }}>
                    <Sparkles size={14} color={T.white} />
                  </button>
                </div>
                <span style={{ fontSize: "12px", color: T.blue, cursor: "pointer", fontWeight: 500 }}>Personalize ▾</span>
              </div>
            </div>
          </div>
          <span style={{ fontSize: "12px", color: T.gray500, display: "block", marginTop: "-10px", marginBottom: "16px" }}>{maxChars - postContent.length} characters left</span>

          {/* Tags */}
          <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px", marginBottom: "16px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>Tags</span>
                <HelpCircle size={14} color={T.gray400} />
              </div>
              <span style={{ fontSize: "13px", color: T.blue, cursor: "pointer", fontWeight: 500 }}>Manage tags</span>
            </div>
            <input placeholder="Search or create a tag" style={{ width: "100%", padding: "9px 14px", border: `1px solid ${T.gray200}`, borderRadius: T.radiusSm, fontSize: "13px", fontFamily: T.font, outline: "none", boxSizing: "border-box" }} />
          </div>

          {/* Approvals */}
          <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px", marginBottom: "16px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "10px" }}>
              <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>Approvals</span>
              <HelpCircle size={14} color={T.gray400} />
            </div>
            <Select value="" placeholder="Select workflow" options={["Manager approval", "Team lead review", "Auto-approve"]} onChange={() => {}} />
          </div>

          {/* Posting checklist */}
          <div style={{ background: T.white, borderRadius: T.radius, border: `1px solid ${T.gray200}`, padding: "16px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
              <span style={{ fontSize: "14px", fontWeight: 500, color: T.gray800 }}>Posting checklist</span>
              <ChevronUp size={16} color={T.gray400} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                <AlertTriangle size={14} color={T.yellow} style={{ marginTop: "2px", flexShrink: 0 }} />
                <span style={{ fontSize: "13px", color: T.gray600, lineHeight: "18px" }}>Instagram's daily limit for sharing posts, reels, and stories combined is 50.</span>
              </div>
              <div style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                <AlertTriangle size={14} color={T.yellow} style={{ marginTop: "2px", flexShrink: 0 }} />
                <span style={{ fontSize: "13px", color: T.gray600, lineHeight: "18px" }}>
                  The <span style={{ color: T.blue, cursor: "pointer" }}>Google</span>, <span style={{ color: T.blue, cursor: "pointer" }}>LinkedIn</span> or <span style={{ color: T.blue, cursor: "pointer" }}>Tiktok</span> accounts of at least one of your locations is disconnected or missing required permissions.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Middle: Preview pane */}
        <div style={{
          width: panelOpen ? "300px" : "380px", transition: "width 0.3s ease",
          borderLeft: `1px solid ${T.gray200}`, background: T.white, overflow: "auto", padding: "20px", flexShrink: 0,
        }}>
          <span style={{ fontSize: "14px", fontWeight: 600, color: T.gray800 }}>Preview</span>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "4px", marginTop: "4px", marginBottom: "16px" }}>
            <HelpCircle size={13} color={T.gray400} style={{ marginTop: "1px", flexShrink: 0 }} />
            <p style={{ fontSize: "11px", color: T.gray500, margin: 0, lineHeight: "15px" }}>
              This is how your post would appear on social channels where it's posted. Published posts may slightly differ from the preview.
            </p>
          </div>

          {channels.length > 0 ? (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "14px" }}>
                <ChannelIcon type={channels[0]} />
                <span style={{ fontSize: "13px", fontWeight: 500, color: T.gray800, textTransform: "capitalize" }}>{channels[0]}</span>
                <span style={{ fontSize: "13px", color: T.blue }}>{channels[0] === "facebook" ? "2 Pages" : "1 Page"}</span>
                <div style={{ flex: 1 }} />
                <ChevronUp size={16} color={T.gray400} />
              </div>

              <div style={{ border: `1px solid ${T.gray200}`, borderRadius: T.radius, overflow: "hidden" }}>
                <div style={{ padding: "14px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "10px" }}>
                    <div style={{ width: 36, height: 36, borderRadius: "50%", background: brands[0]?.logoColor || T.gray300, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px" }}>{brands[0]?.logo || "?"}</div>
                    <div>
                      <div style={{ fontSize: "13px", fontWeight: 600, color: T.gray900 }}>{brands[0]?.name || "Your Brand"}</div>
                      <div style={{ fontSize: "11px", color: T.gray500 }}>Just now · 🌐</div>
                    </div>
                  </div>
                  <p style={{ fontSize: "13px", color: T.gray700, lineHeight: "20px", margin: 0 }}>
                    {postContent.length > 200 ? postContent.substring(0, 200) + "..." : postContent}
                  </p>
                </div>
                <div style={{ height: "120px", background: `linear-gradient(135deg, ${brands[0]?.kit.colors.primary || T.blue}, ${brands[0]?.kit.colors.dark || T.gray800})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Image size={32} color="rgba(255,255,255,0.5)" />
                </div>
              </div>
            </>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 20px", color: T.gray400 }}>
              <div style={{ width: 80, height: 60, background: T.gray100, borderRadius: T.radius, marginBottom: "12px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Monitor size={24} color={T.gray300} />
              </div>
              <p style={{ fontSize: "13px", textAlign: "center" }}>Select a channel and start creating a post to see a preview.</p>
            </div>
          )}
        </div>

        {/* Right: Brand Score Panel */}
        <BrandScoreDrawer
          open={panelOpen}
          onClose={() => setPanelOpen(false)}
          brands={brands}
          postContent={postContent}
          channels={channels}
          onOpenSettings={() => { setPanelOpen(false); /* navigate handled by parent */ }}
        />
      </div>
    </div>
  );
}


/* ════════════════════════════════════════════════════════════════
   APP ROOT — router between pages
   ════════════════════════════════════════════════════════════════ */
export default function BrandScoreApp() {
  const [page, setPage] = useState("createpost");
  const [brands, setBrands] = useState(DEFAULT_BRANDS);

  return (
    <div style={{ fontFamily: T.font, background: "#F5F7FA", height: "100vh", display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <TopNav onSettings={() => setPage("brand-identity")} />
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        <LeftNav activePage={page} onNavigate={setPage} />
        {page === "brand-identity" && <BrandIdentityPage brands={brands} setBrands={setBrands} onNavigate={setPage} />}
        {page === "createpost" && <CreatePostPage brands={brands} onNavigate={setPage} />}
        {page !== "brand-identity" && page !== "createpost" && (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: "12px" }}>
            <span style={{ fontSize: "40px" }}>🚧</span>
            <span style={{ fontSize: "15px", color: T.gray500 }}>Navigate to <strong>Social</strong> (post icon) or <strong>Settings</strong> (gear icon) to explore the prototype</span>
          </div>
        )}
      </div>
    </div>
  );
}

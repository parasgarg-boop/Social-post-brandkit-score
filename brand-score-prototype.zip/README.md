# Brand Score — Birdeye Social Prototype

Interactive prototype for the **Brand Score** feature in Birdeye Social's Create Post screen. Scores social media posts against a selected brand identity across four dimensions:

- **Brand Voice** — personality, tone, and writing style alignment
- **Visual Identity** — colors, fonts, and logo usage
- **CTA Alignment** — call-to-action effectiveness and brand consistency
- **Hashtags & Keywords** — relevance and brand keyword coverage

## Quick Start

```bash
npm install
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173) in your browser.

## Build for Production

```bash
npm run build
npm run preview
```

## Tech Stack

- React 18
- Vite
- Recharts (score visualizations)
- Lucide React (icons)

## Files

| File | Description |
|------|-------------|
| `src/BrandScoreApp.jsx` | Full Create Post screen with integrated brand scoring |
| `src/BrandScorePanel.jsx` | Standalone brand score panel component |
